
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/db.ts
import { neon } from "@neondatabase/serverless";
var sql = neon(process.env.DATABASE_URL);

// netlify/functions/_shared/auth-middleware.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function getTokenFromHeaders(headers) {
  const auth = headers["authorization"] || headers["Authorization"];
  if (!auth?.startsWith("Bearer ")) return null;
  return auth.slice(7);
}
function unauthorized(message = "Unauthorized") {
  return new Response(JSON.stringify({ error: message }), {
    status: 401,
    headers: { "Content-Type": "application/json" }
  });
}
function forbidden(message = "Forbidden") {
  return new Response(JSON.stringify({ error: message }), {
    status: 403,
    headers: { "Content-Type": "application/json" }
  });
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// netlify/functions/admin-users-list.ts
var admin_users_list_default = async (request, _context) => {
  const token = getTokenFromHeaders(
    Object.fromEntries(request.headers.entries())
  );
  if (!token) return unauthorized();
  const payload = verifyToken(token);
  if (!payload) return unauthorized("Invalid or expired token");
  if (payload.role !== "admin") return forbidden();
  const url = new URL(request.url);
  const clientSlug = url.searchParams.get("clientSlug");
  const users = clientSlug ? await sql`
        SELECT
          u.id, u.email, u.name, u.role, u.client_id,
          u.created_at, u.last_login_at,
          c.name AS client_name, c.slug AS client_slug
        FROM users u
        JOIN clients c ON u.client_id = c.id
        WHERE c.slug = ${clientSlug}
        ORDER BY u.name
      ` : await sql`
        SELECT
          u.id, u.email, u.name, u.role, u.client_id,
          u.created_at, u.last_login_at,
          c.name AS client_name, c.slug AS client_slug
        FROM users u
        LEFT JOIN clients c ON u.client_id = c.id
        ORDER BY u.role DESC, u.name
      `;
  return jsonResponse({ users });
};
export {
  admin_users_list_default as default
};
