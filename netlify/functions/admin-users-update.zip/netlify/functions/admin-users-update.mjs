
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/admin-users-update.ts
import bcrypt from "bcryptjs";

// netlify/functions/_shared/db.ts
import { neon } from "@neondatabase/serverless";
var sql = neon(process.env.DATABASE_URL);

// netlify/functions/_shared/auth-middleware.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function getTokenFromHeaders(headers) {
  const auth = headers["authorization"] || headers["Authorization"];
  if (!auth?.startsWith("Bearer ")) return null;
  return auth.slice(7);
}
function unauthorized(message = "Unauthorized") {
  return new Response(JSON.stringify({ error: message }), {
    status: 401,
    headers: { "Content-Type": "application/json" }
  });
}
function forbidden(message = "Forbidden") {
  return new Response(JSON.stringify({ error: message }), {
    status: 403,
    headers: { "Content-Type": "application/json" }
  });
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// netlify/functions/admin-users-update.ts
var admin_users_update_default = async (request, _context) => {
  if (request.method !== "PUT") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  const token = getTokenFromHeaders(
    Object.fromEntries(request.headers.entries())
  );
  if (!token) return unauthorized();
  const payload = verifyToken(token);
  if (!payload) return unauthorized("Invalid or expired token");
  if (payload.role !== "admin") return forbidden();
  const body = await request.json();
  const { id, email, name, role, clientId, password } = body;
  if (!id) {
    return jsonResponse({ error: "id is required" }, 400);
  }
  if (!email || !name || !role) {
    return jsonResponse({ error: "email, name, and role are required" }, 400);
  }
  if (!["admin", "client"].includes(role)) {
    return jsonResponse({ error: "role must be admin or client" }, 400);
  }
  if (role === "client" && !clientId) {
    return jsonResponse({ error: "clientId is required for client role" }, 400);
  }
  if (password && password.length < 8) {
    return jsonResponse({ error: "password must be at least 8 characters" }, 400);
  }
  const existing = await sql`SELECT id FROM users WHERE email = ${email} AND id != ${id}`;
  if (existing.length > 0) {
    return jsonResponse({ error: "A user with this email already exists" }, 409);
  }
  if (password) {
    const hash = await bcrypt.hash(password, 12);
    const [user] = await sql`
      UPDATE users
      SET email = ${email}, name = ${name}, role = ${role},
          client_id = ${role === "client" ? clientId : null},
          password_hash = ${hash}
      WHERE id = ${id}
      RETURNING id, email, name, role, client_id
    `;
    if (!user) return jsonResponse({ error: "User not found" }, 404);
    return jsonResponse({ user });
  } else {
    const [user] = await sql`
      UPDATE users
      SET email = ${email}, name = ${name}, role = ${role},
          client_id = ${role === "client" ? clientId : null}
      WHERE id = ${id}
      RETURNING id, email, name, role, client_id
    `;
    if (!user) return jsonResponse({ error: "User not found" }, 404);
    return jsonResponse({ user });
  }
};
export {
  admin_users_update_default as default
};
