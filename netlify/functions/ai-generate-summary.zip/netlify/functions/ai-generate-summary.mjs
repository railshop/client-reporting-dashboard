
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/ai-generate-summary.ts
import Anthropic from "@anthropic-ai/sdk";

// netlify/functions/_shared/db.ts
import { neon } from "@neondatabase/serverless";
var sql = neon(process.env.DATABASE_URL);

// netlify/functions/_shared/auth-middleware.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function getTokenFromHeaders(headers) {
  const auth = headers["authorization"] || headers["Authorization"];
  if (!auth?.startsWith("Bearer ")) return null;
  return auth.slice(7);
}
function unauthorized(message = "Unauthorized") {
  return new Response(JSON.stringify({ error: message }), {
    status: 401,
    headers: { "Content-Type": "application/json" }
  });
}
function forbidden(message = "Forbidden") {
  return new Response(JSON.stringify({ error: message }), {
    status: 403,
    headers: { "Content-Type": "application/json" }
  });
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// src/shared/schemas/sources/ga4.ts
import { z as z2 } from "zod";

// src/shared/schemas/common.ts
import { z } from "zod";
var kpiItemSchema = z.object({
  label: z.string(),
  value: z.string(),
  delta: z.string(),
  direction: z.enum(["up", "down", "neutral"]),
  color: z.enum(["blue", "green", "gold", "default"]).default("default")
});
var columnDefSchema = z.object({
  key: z.string(),
  label: z.string(),
  align: z.enum(["left", "right"]).default("left")
});
var tableDefSchema = z.object({
  title: z.string(),
  columns: z.array(columnDefSchema),
  rows: z.array(z.record(z.string(), z.union([z.string(), z.number()]))),
  footerRow: z.record(z.string(), z.union([z.string(), z.number()])).optional()
});
var overviewSchema = z.object({
  headline: z.string().optional(),
  summary: z.string().optional(),
  hero_stats: z.array(kpiItemSchema).optional(),
  platform_cards: z.array(z.object({
    platform: z.string(),
    metrics: z.array(z.object({
      label: z.string(),
      value: z.string()
    })),
    spend: z.string()
  })).optional()
});

// src/shared/schemas/sources/ga4.ts
var ga4SectionSchema = z2.object({
  kpis: z2.array(kpiItemSchema).min(1),
  tables: z2.object({
    channelBreakdown: tableDefSchema,
    topLandingPages: tableDefSchema
  })
});

// src/shared/schemas/sources/gsc.ts
import { z as z3 } from "zod";
var gscSectionSchema = z3.object({
  kpis: z3.array(kpiItemSchema).min(1),
  tables: z3.object({
    topQueries: tableDefSchema,
    topPages: tableDefSchema,
    positionDistribution: tableDefSchema.optional(),
    deviceBreakdown: tableDefSchema.optional()
  })
});

// src/shared/schemas/sources/google-ads.ts
import { z as z4 } from "zod";
var googleAdsSectionSchema = z4.object({
  kpis: z4.array(kpiItemSchema).min(1),
  tables: z4.object({
    assetGroupPerformance: tableDefSchema.optional()
  })
});
var googleAdsCampaignSchema = z4.object({
  campaign_name: z4.string(),
  campaign_type: z4.string(),
  metrics: z4.object({
    impressions: z4.number(),
    clicks: z4.number(),
    ctr: z4.string(),
    cpc: z4.string(),
    conversions: z4.number(),
    cost_per_conversion: z4.string(),
    spend: z4.string(),
    roas: z4.string().optional()
  })
});

// src/shared/schemas/sources/meta.ts
import { z as z5 } from "zod";
var metaSectionSchema = z5.object({
  kpis: z5.array(kpiItemSchema).min(1),
  tables: z5.object({
    creativeBreakdown: tableDefSchema.optional()
  })
});
var metaCampaignSchema = z5.object({
  campaign_name: z5.string(),
  campaign_type: z5.string(),
  metrics: z5.object({
    reach: z5.number(),
    frequency: z5.string(),
    impressions: z5.number(),
    clicks: z5.number(),
    ctr: z5.string(),
    leads: z5.number(),
    cpl: z5.string(),
    spend: z5.string()
  })
});

// src/shared/schemas/sources/lsa.ts
import { z as z6 } from "zod";
var lsaSectionSchema = z6.object({
  kpis: z6.array(kpiItemSchema).min(1),
  tables: z6.object({}).optional()
});

// src/shared/schemas/sources/servicetitan.ts
import { z as z7 } from "zod";
var servicetitanSectionSchema = z7.object({
  kpis: z7.array(kpiItemSchema).min(1),
  tables: z7.object({
    campaignPerformance: tableDefSchema.optional()
  })
});

// src/shared/schemas/sources/gbp.ts
import { z as z8 } from "zod";
var gbpSectionSchema = z8.object({
  kpis: z8.array(kpiItemSchema).min(1),
  tables: z8.object({
    searchQueries: tableDefSchema.optional(),
    photoViews: tableDefSchema.optional()
  })
});

// src/shared/schemas/sources/index.ts
var SOURCE_LABELS = {
  ga4: "Website",
  gsc: "SEO",
  google_ads: "Google Ads",
  meta: "Meta",
  lsa: "LSA",
  servicetitan: "ServiceTitan",
  gbp: "Google Business"
};

// netlify/functions/_shared/ai-prompts.ts
function buildRawDataContext(ingestions, previousIngestions, mechanicalSections) {
  let context = "";
  for (const ing of ingestions) {
    const sourceLabel = SOURCE_LABELS[ing.source] || ing.source;
    context += `
## ${sourceLabel} (${ing.source}) \u2014 Current Period
`;
    context += JSON.stringify(ing.raw_data, null, 2) + "\n";
    const prev = previousIngestions.find((p) => p.source === ing.source);
    if (prev) {
      context += `
## ${sourceLabel} (${ing.source}) \u2014 Previous Period
`;
      context += JSON.stringify(prev.raw_data, null, 2) + "\n";
    }
    const mechanical = mechanicalSections?.find((s) => s.source === ing.source);
    if (mechanical) {
      context += `
## ${sourceLabel} (${ing.source}) \u2014 Computed KPIs
`;
      context += JSON.stringify(mechanical.kpis, null, 2) + "\n";
      if (mechanical.campaigns?.length) {
        context += `
## ${sourceLabel} (${ing.source}) \u2014 Campaigns
`;
        context += JSON.stringify(mechanical.campaigns, null, 2) + "\n";
      }
    }
  }
  return context;
}
function buildSectionDataContext(source, rawData, previousRawData, mechanicalKpis, mechanicalCampaigns) {
  const sourceLabel = SOURCE_LABELS[source] || source;
  let context = `
## ${sourceLabel} (${source}) \u2014 Current Period
`;
  context += JSON.stringify(rawData, null, 2) + "\n";
  if (previousRawData) {
    context += `
## ${sourceLabel} (${source}) \u2014 Previous Period
`;
    context += JSON.stringify(previousRawData, null, 2) + "\n";
  }
  if (mechanicalKpis) {
    context += `
## ${sourceLabel} (${source}) \u2014 Computed KPIs
`;
    context += JSON.stringify(mechanicalKpis, null, 2) + "\n";
  }
  if (mechanicalCampaigns?.length) {
    context += `
## ${sourceLabel} (${source}) \u2014 Campaigns
`;
    context += JSON.stringify(mechanicalCampaigns, null, 2) + "\n";
  }
  return context;
}

// netlify/functions/ai-generate-summary.ts
var SYSTEM_PROMPT = `You are a digital marketing analyst writing monthly performance summaries for Railshop, a marketing agency. Your tone is professional, data-driven, and actionable. Write in 2-3 concise paragraphs. Reference specific numbers and trends from the data provided. Highlight wins, flag concerns, and suggest next steps where appropriate. Do not use bullet points or headers \u2014 write flowing prose paragraphs.`;
var ai_generate_summary_default = async (request, _context) => {
  if (request.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  const token = getTokenFromHeaders(
    Object.fromEntries(request.headers.entries())
  );
  if (!token) return unauthorized();
  const payload = verifyToken(token);
  if (!payload) return unauthorized("Invalid or expired token");
  if (payload.role !== "admin") return forbidden();
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return jsonResponse({ error: "ANTHROPIC_API_KEY not configured" }, 500);
  }
  const body = await request.json();
  const { source, kpis, tables, campaigns, userPrompt, type, fromRawData, clientSlug, periodStart } = body;
  if (!type || !["section", "overview"].includes(type)) {
    return jsonResponse({ error: 'type must be "section" or "overview"' }, 400);
  }
  let dataContext = "";
  if (fromRawData && clientSlug && periodStart) {
    const clients = await sql`SELECT id FROM clients WHERE slug = ${clientSlug}`;
    if (clients.length > 0) {
      const clientId = clients[0].id;
      if (type === "section" && source) {
        const ingestions = await sql`
          SELECT raw_data FROM raw_ingestions
          WHERE client_id = ${clientId} AND source = ${source} AND period_start = ${periodStart}
        `;
        if (ingestions.length > 0) {
          const prevDate = /* @__PURE__ */ new Date(periodStart + "T00:00:00");
          const prevYear = prevDate.getMonth() === 0 ? prevDate.getFullYear() - 1 : prevDate.getFullYear();
          const prevMonth = prevDate.getMonth() === 0 ? 12 : prevDate.getMonth();
          const prevPeriodStart = `${prevYear}-${String(prevMonth).padStart(2, "0")}-01`;
          const prevIngestions = await sql`
            SELECT raw_data FROM raw_ingestions
            WHERE client_id = ${clientId} AND source = ${source} AND period_start = ${prevPeriodStart}
          `;
          dataContext = `This is a section summary for: ${SOURCE_LABELS[source] || source}

`;
          dataContext += buildSectionDataContext(source, ingestions[0].raw_data, prevIngestions[0]?.raw_data);
        }
      } else if (type === "overview") {
        const ingestions = await sql`
          SELECT source, raw_data FROM raw_ingestions
          WHERE client_id = ${clientId} AND period_start = ${periodStart}
        `;
        if (ingestions.length > 0) {
          const prevDate = /* @__PURE__ */ new Date(periodStart + "T00:00:00");
          const prevYear = prevDate.getMonth() === 0 ? prevDate.getFullYear() - 1 : prevDate.getFullYear();
          const prevMonth = prevDate.getMonth() === 0 ? 12 : prevDate.getMonth();
          const prevPeriodStart = `${prevYear}-${String(prevMonth).padStart(2, "0")}-01`;
          const prevIngestions = await sql`
            SELECT source, raw_data FROM raw_ingestions
            WHERE client_id = ${clientId} AND period_start = ${prevPeriodStart}
          `;
          dataContext = "This is an overview summary for the entire monthly report.\n\n";
          dataContext += buildRawDataContext(ingestions, prevIngestions);
        }
      }
    }
  }
  if (!dataContext) {
    if (type === "overview") {
      dataContext = "This is an overview summary for the entire monthly report.\n\n";
      if (kpis?.length) {
        dataContext += "Hero Stats:\n";
        for (const k of kpis) {
          dataContext += `- ${k.label}: ${k.value}${k.delta ? ` (${k.direction === "up" ? "+" : ""}${k.delta} vs last month)` : ""}
`;
        }
        dataContext += "\n";
      }
      if (tables && Object.keys(tables).length) {
        dataContext += "Platform Summary:\n";
        dataContext += JSON.stringify(tables, null, 2) + "\n\n";
      }
    } else {
      dataContext = `This is a section summary for: ${source}

`;
      if (kpis?.length) {
        dataContext += "KPIs:\n";
        for (const k of kpis) {
          dataContext += `- ${k.label}: ${k.value}${k.delta ? ` (${k.direction === "up" ? "+" : ""}${k.delta} vs last month)` : ""}
`;
        }
        dataContext += "\n";
      }
      if (tables && Object.keys(tables).length) {
        for (const [key, table] of Object.entries(tables)) {
          dataContext += `Table \u2014 ${table.title || key}:
`;
          if (table.columns && table.rows) {
            const headers = table.columns.map((c) => c.label).join(" | ");
            dataContext += headers + "\n";
            for (const row of table.rows.slice(0, 20)) {
              const vals = table.columns.map((c) => row[c.key] ?? "").join(" | ");
              dataContext += vals + "\n";
            }
          }
          dataContext += "\n";
        }
      }
      if (campaigns?.length) {
        dataContext += "Campaigns:\n";
        for (const c of campaigns.slice(0, 20)) {
          dataContext += `- ${c.campaign_name} (${c.campaign_type || "unknown"}): ${JSON.stringify(c.metrics)}
`;
        }
        dataContext += "\n";
      }
    }
  }
  const userMessage = userPrompt ? `${dataContext}
Additional context from the admin: ${userPrompt}

Write the summary.` : `${dataContext}
Write the summary.`;
  try {
    const client = new Anthropic({ apiKey });
    const response = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 1024,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: userMessage }]
    });
    const textBlock = response.content.find((b) => b.type === "text");
    const summary = textBlock ? textBlock.text : "";
    return jsonResponse({ summary });
  } catch (err) {
    return jsonResponse({ error: err.message || "AI generation failed" }, 500);
  }
};
export {
  ai_generate_summary_default as default
};
