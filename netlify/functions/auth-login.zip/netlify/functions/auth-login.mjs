
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/auth-login.ts
import bcrypt from "bcryptjs";

// netlify/functions/_shared/db.ts
import { neon } from "@neondatabase/serverless";
var sql = neon(process.env.DATABASE_URL);

// netlify/functions/_shared/auth-middleware.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function signToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: "7d" });
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// netlify/functions/auth-login.ts
var auth_login_default = async (request, _context) => {
  if (request.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  const { email, password } = await request.json();
  if (!email || !password) {
    return jsonResponse({ error: "Email and password are required" }, 400);
  }
  const rows = await sql`
    SELECT u.id, u.email, u.name, u.role, u.password_hash, u.client_id, c.slug as client_slug
    FROM users u
    LEFT JOIN clients c ON u.client_id = c.id
    WHERE u.email = ${email}
  `;
  if (rows.length === 0) {
    return jsonResponse({ error: "Invalid email or password" }, 401);
  }
  const user = rows[0];
  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) {
    return jsonResponse({ error: "Invalid email or password" }, 401);
  }
  await sql`UPDATE users SET last_login_at = now() WHERE id = ${user.id}`;
  const token = signToken({
    userId: user.id,
    role: user.role,
    clientId: user.client_id,
    clientSlug: user.client_slug
  });
  return jsonResponse({
    token,
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      clientSlug: user.client_slug
    }
  });
};
export {
  auth_login_default as default
};
