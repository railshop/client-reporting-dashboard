
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/db.ts
import { neon } from "@neondatabase/serverless";
var sql = neon(process.env.DATABASE_URL);

// netlify/functions/_shared/auth-middleware.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function getTokenFromHeaders(headers) {
  const auth = headers["authorization"] || headers["Authorization"];
  if (!auth?.startsWith("Bearer ")) return null;
  return auth.slice(7);
}
function unauthorized(message = "Unauthorized") {
  return new Response(JSON.stringify({ error: message }), {
    status: 401,
    headers: { "Content-Type": "application/json" }
  });
}
function forbidden(message = "Forbidden") {
  return new Response(JSON.stringify({ error: message }), {
    status: 403,
    headers: { "Content-Type": "application/json" }
  });
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// netlify/functions/client-get.ts
var client_get_default = async (request, _context) => {
  const token = getTokenFromHeaders(
    Object.fromEntries(request.headers.entries())
  );
  if (!token) return unauthorized();
  const payload = verifyToken(token);
  if (!payload) return unauthorized("Invalid or expired token");
  if (payload.role !== "admin") return forbidden();
  const url = new URL(request.url);
  const clientSlug = url.searchParams.get("client");
  if (!clientSlug) {
    return jsonResponse({ error: "client query param required" }, 400);
  }
  const clients = await sql`
    SELECT id, slug, name, logo_url, active, created_at
    FROM clients WHERE slug = ${clientSlug}
  `;
  if (clients.length === 0) {
    return jsonResponse({ error: "Client not found" }, 404);
  }
  const client = clients[0];
  const sources = await sql`
    SELECT id, source, config, active, created_at
    FROM client_data_sources
    WHERE client_id = ${client.id}
    ORDER BY source
  `;
  const sourcesWithFlag = sources.map((s) => {
    const config = s.config || {};
    return {
      id: s.id,
      source: s.source,
      active: s.active,
      has_credentials: !!config.credentials_encrypted,
      // Return non-secret identifiers only
      identifiers: Object.fromEntries(
        Object.entries(config).filter(([k]) => k !== "credentials_encrypted")
      ),
      created_at: s.created_at
    };
  });
  return jsonResponse({
    client: {
      id: client.id,
      slug: client.slug,
      name: client.name,
      logo_url: client.logo_url,
      active: client.active,
      created_at: client.created_at
    },
    sources: sourcesWithFlag
  });
};
export {
  client_get_default as default
};
