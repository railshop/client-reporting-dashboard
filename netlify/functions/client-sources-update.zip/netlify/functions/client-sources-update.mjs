
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/shared/schemas/credentials.ts
var credentials_exports = {};
__export(credentials_exports, {
  CREDENTIAL_FIELDS: () => CREDENTIAL_FIELDS,
  credentialSchemaMap: () => credentialSchemaMap,
  ga4CredentialsSchema: () => ga4CredentialsSchema,
  gbpCredentialsSchema: () => gbpCredentialsSchema,
  googleAdsCredentialsSchema: () => googleAdsCredentialsSchema,
  gscCredentialsSchema: () => gscCredentialsSchema,
  lsaCredentialsSchema: () => lsaCredentialsSchema,
  metaCredentialsSchema: () => metaCredentialsSchema,
  servicetitanCredentialsSchema: () => servicetitanCredentialsSchema
});
import { z } from "zod";
var ga4CredentialsSchema, gscCredentialsSchema, googleAdsCredentialsSchema, metaCredentialsSchema, lsaCredentialsSchema, servicetitanCredentialsSchema, gbpCredentialsSchema, credentialSchemaMap, CREDENTIAL_FIELDS;
var init_credentials = __esm({
  "src/shared/schemas/credentials.ts"() {
    ga4CredentialsSchema = z.object({
      service_account_json: z.string().min(1),
      property_id: z.string().min(1)
    });
    gscCredentialsSchema = z.object({
      service_account_json: z.string().min(1),
      site_url: z.string().min(1)
    });
    googleAdsCredentialsSchema = z.object({
      client_id: z.string().min(1),
      client_secret: z.string().min(1),
      developer_token: z.string().min(1),
      refresh_token: z.string().min(1),
      customer_id: z.string().min(1),
      manager_account_id: z.string().min(1)
    });
    metaCredentialsSchema = z.object({
      access_token: z.string().min(1),
      ad_account_id: z.string().min(1)
    });
    lsaCredentialsSchema = z.object({});
    servicetitanCredentialsSchema = z.object({});
    gbpCredentialsSchema = z.object({
      service_account_json: z.string().min(1),
      account_id: z.string().min(1),
      location_id: z.string().min(1)
    });
    credentialSchemaMap = {
      ga4: ga4CredentialsSchema,
      gsc: gscCredentialsSchema,
      google_ads: googleAdsCredentialsSchema,
      meta: metaCredentialsSchema,
      lsa: lsaCredentialsSchema,
      servicetitan: servicetitanCredentialsSchema,
      gbp: gbpCredentialsSchema
    };
    CREDENTIAL_FIELDS = {
      ga4: {
        service_account_json: { label: "Service Account JSON", secret: true, multiline: true },
        property_id: { label: "Property ID", secret: false }
      },
      gsc: {
        service_account_json: { label: "Service Account JSON", secret: true, multiline: true },
        site_url: { label: "Site URL", secret: false }
      },
      google_ads: {
        client_id: { label: "OAuth Client ID", secret: true },
        client_secret: { label: "OAuth Client Secret", secret: true },
        developer_token: { label: "Developer Token", secret: true },
        refresh_token: { label: "Refresh Token", secret: true },
        customer_id: { label: "Customer ID", secret: false },
        manager_account_id: { label: "Manager Account ID", secret: false }
      },
      meta: {
        access_token: { label: "Access Token", secret: true },
        ad_account_id: { label: "Ad Account ID", secret: false }
      },
      lsa: {},
      servicetitan: {},
      gbp: {
        service_account_json: { label: "Service Account JSON", secret: true, multiline: true },
        account_id: { label: "Account ID", secret: false },
        location_id: { label: "Location ID", secret: false }
      }
    };
  }
});

// netlify/functions/_shared/db.ts
import { neon } from "@neondatabase/serverless";
var sql = neon(process.env.DATABASE_URL);

// netlify/functions/_shared/auth-middleware.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function getTokenFromHeaders(headers) {
  const auth = headers["authorization"] || headers["Authorization"];
  if (!auth?.startsWith("Bearer ")) return null;
  return auth.slice(7);
}
function unauthorized(message = "Unauthorized") {
  return new Response(JSON.stringify({ error: message }), {
    status: 401,
    headers: { "Content-Type": "application/json" }
  });
}
function forbidden(message = "Forbidden") {
  return new Response(JSON.stringify({ error: message }), {
    status: 403,
    headers: { "Content-Type": "application/json" }
  });
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// netlify/functions/_shared/crypto.ts
import crypto from "crypto";
var ALGORITHM = "aes-256-gcm";
var IV_LENGTH = 12;
var TAG_LENGTH = 16;
function getKey() {
  const hex = process.env.ENCRYPTION_MASTER_KEY;
  if (!hex || hex.length !== 64) {
    throw new Error("ENCRYPTION_MASTER_KEY must be a 64-char hex string");
  }
  return Buffer.from(hex, "hex");
}
function encrypt(plaintext) {
  const key = getKey();
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, encrypted]).toString("base64");
}
function decrypt(encoded) {
  const key = getKey();
  const buf = Buffer.from(encoded, "base64");
  const iv = buf.subarray(0, IV_LENGTH);
  const tag = buf.subarray(IV_LENGTH, IV_LENGTH + TAG_LENGTH);
  const ciphertext = buf.subarray(IV_LENGTH + TAG_LENGTH);
  const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
  decipher.setAuthTag(tag);
  return decipher.update(ciphertext) + decipher.final("utf8");
}

// netlify/functions/client-sources-update.ts
init_credentials();
var client_sources_update_default = async (request, _context) => {
  if (request.method !== "PUT") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  const token = getTokenFromHeaders(
    Object.fromEntries(request.headers.entries())
  );
  if (!token) return unauthorized();
  const payload = verifyToken(token);
  if (!payload) return unauthorized("Invalid or expired token");
  if (payload.role !== "admin") return forbidden();
  const body = await request.json();
  const { clientSlug, source, credentials, active } = body;
  if (!clientSlug || !source) {
    return jsonResponse({ error: "clientSlug and source are required" }, 400);
  }
  const validSources = Object.keys(credentialSchemaMap);
  if (!validSources.includes(source)) {
    return jsonResponse({ error: `Invalid source: ${source}` }, 400);
  }
  const clients = await sql`SELECT id FROM clients WHERE slug = ${clientSlug}`;
  if (clients.length === 0) {
    return jsonResponse({ error: "Client not found" }, 404);
  }
  const clientId = clients[0].id;
  const config = {};
  if (credentials && Object.keys(credentials).length > 0) {
    const { CREDENTIAL_FIELDS: CREDENTIAL_FIELDS2 } = await Promise.resolve().then(() => (init_credentials(), credentials_exports));
    const fields = CREDENTIAL_FIELDS2[source];
    const hasPartialSecrets = Object.entries(fields).some(
      ([key, def]) => def.secret && !credentials[key]
    );
    let mergedCredentials = { ...credentials };
    if (hasPartialSecrets) {
      const existingRows = await sql`
        SELECT config FROM client_data_sources
        WHERE client_id = ${clientId} AND source = ${source}
      `;
      if (existingRows.length > 0 && existingRows[0].config?.credentials_encrypted) {
        try {
          const existing = JSON.parse(decrypt(existingRows[0].config.credentials_encrypted));
          for (const [key, def] of Object.entries(fields)) {
            if (def.secret && !mergedCredentials[key] && existing[key]) {
              mergedCredentials[key] = existing[key];
            }
          }
        } catch {
        }
      }
    }
    const schema = credentialSchemaMap[source];
    const parsed = schema.safeParse(mergedCredentials);
    if (!parsed.success) {
      return jsonResponse(
        { error: "Invalid credentials", details: parsed.error.flatten().fieldErrors },
        400
      );
    }
    config.credentials_encrypted = encrypt(JSON.stringify(parsed.data));
    for (const [key, def] of Object.entries(fields)) {
      if (!def.secret && parsed.data[key]) {
        config[key] = String(parsed.data[key]);
      }
    }
  }
  const result = await sql`
    INSERT INTO client_data_sources (client_id, source, config, active)
    VALUES (${clientId}, ${source}, ${JSON.stringify(config)}, ${active ?? true})
    ON CONFLICT (client_id, source)
    DO UPDATE SET
      config = CASE
        WHEN ${Object.keys(config).length > 0} THEN ${JSON.stringify(config)}::jsonb
        ELSE client_data_sources.config
      END,
      active = COALESCE(${active ?? null}, client_data_sources.active)
    RETURNING id, source, active
  `;
  return jsonResponse({ source: result[0] });
};
export {
  client_sources_update_default as default
};
