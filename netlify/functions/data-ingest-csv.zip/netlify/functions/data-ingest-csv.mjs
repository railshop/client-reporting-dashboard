
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/db.ts
import { neon } from "@neondatabase/serverless";
var sql = neon(process.env.DATABASE_URL);

// netlify/functions/_shared/auth-middleware.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function getTokenFromHeaders(headers) {
  const auth = headers["authorization"] || headers["Authorization"];
  if (!auth?.startsWith("Bearer ")) return null;
  return auth.slice(7);
}
function unauthorized(message = "Unauthorized") {
  return new Response(JSON.stringify({ error: message }), {
    status: 401,
    headers: { "Content-Type": "application/json" }
  });
}
function forbidden(message = "Forbidden") {
  return new Response(JSON.stringify({ error: message }), {
    status: 403,
    headers: { "Content-Type": "application/json" }
  });
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// src/shared/schemas/csv-mappings.ts
var CSV_SOURCE_MAPPINGS = {
  ga4: {
    label: "Website (GA4)",
    description: "Import GA4 summary metrics. One row with aggregate values.",
    mode: "summary",
    columns: [
      { field: "newUsers", label: "New Users", type: "number", required: true },
      { field: "sessions", label: "Sessions", type: "number", required: true },
      { field: "organicSessions", label: "Organic Sessions", type: "number" },
      { field: "directSessions", label: "Direct Sessions", type: "number" },
      { field: "paidSessions", label: "Paid Sessions", type: "number" }
      // TODO: Add conversions once GA4 conversion events are configured per client
      // { field: 'conversions', label: 'Conversions', type: 'number' },
    ]
  },
  gsc: {
    label: "SEO (Search Console)",
    description: "Import Search Console summary metrics.",
    mode: "summary",
    columns: [
      { field: "clicks", label: "Clicks", type: "number", required: true },
      { field: "impressions", label: "Impressions", type: "number", required: true },
      { field: "ctr", label: "CTR", type: "number" },
      { field: "position", label: "Avg Position", type: "number" }
    ]
  },
  google_ads: {
    label: "Google Ads",
    description: "Import Google Ads campaign data. Each row is a campaign.",
    mode: "detail",
    columns: [
      { field: "campaign_name", label: "Campaign", type: "string", required: true },
      { field: "campaign_type", label: "Campaign Type", type: "string" },
      { field: "impressions", label: "Impressions", type: "number" },
      { field: "clicks", label: "Clicks", type: "number" },
      { field: "conversions", label: "Conversions", type: "number" },
      { field: "spend", label: "Spend", type: "currency" }
    ]
  },
  meta: {
    label: "Meta Ads",
    description: "Import Meta campaign data. Each row is a campaign.",
    mode: "detail",
    columns: [
      { field: "campaign_name", label: "Campaign", type: "string", required: true },
      { field: "reach", label: "Reach", type: "number" },
      { field: "impressions", label: "Impressions", type: "number" },
      { field: "clicks", label: "Clicks", type: "number" },
      { field: "leads", label: "Leads", type: "number" },
      { field: "spend", label: "Spend", type: "currency" }
    ]
  },
  servicetitan: {
    label: "ServiceTitan",
    description: 'Campaign Tracking - Jobs Booked Performance report (.xlsx or .csv). Only "RS -" campaigns are imported.',
    mode: "detail",
    columns: [
      { field: "campaign_name", label: "Campaign Name", type: "string", required: true },
      { field: "jobs_booked", label: "Total Jobs Booked", type: "number", required: true },
      { field: "jobs_booked_new", label: "Jobs Booked from New Customers", type: "number" },
      { field: "jobs_booked_existing", label: "Jobs Booked from Existing Customers", type: "number" },
      { field: "completed_revenue", label: "Completed Revenue", type: "currency" },
      { field: "total_sales", label: "Total Sales", type: "currency" },
      { field: "opportunity_conversion_rate", label: "Opportunity Conversion Rate", type: "number" },
      { field: "revenue_per_lead", label: "Revenue Per Lead", type: "currency" },
      { field: "total_job_average", label: "Total Job Average", type: "currency" }
    ]
  },
  gbp: {
    label: "Google Business Profile",
    description: "Import GBP summary metrics. One row with aggregate values.",
    mode: "summary",
    columns: [
      { field: "totalImpressions", label: "Total Impressions", type: "number" },
      { field: "mapsImpressions", label: "Maps Impressions", type: "number" },
      { field: "searchImpressions", label: "Search Impressions", type: "number" },
      { field: "calls", label: "Phone Calls", type: "number" },
      { field: "websiteClicks", label: "Website Clicks", type: "number" },
      { field: "directions", label: "Direction Requests", type: "number" }
    ]
  }
};
function parseCsvValue(value, type) {
  const trimmed = value.trim();
  if (!trimmed) return type === "string" ? "" : 0;
  if (type === "number") {
    const num = Number(trimmed.replace(/[,%]/g, ""));
    return isNaN(num) ? 0 : num;
  }
  if (type === "currency") {
    const num = Number(trimmed.replace(/[$,]/g, ""));
    return isNaN(num) ? 0 : num;
  }
  return trimmed;
}
function buildRawDataFromCsv(source, rows, mapping) {
  if (mapping.mode === "summary") {
    const current = {};
    const row = rows[0] || {};
    for (const col of mapping.columns) {
      current[col.field] = row[col.field] ?? 0;
    }
    return { current, previous: {} };
  }
  if (source === "google_ads" || source === "meta") {
    const totals = {};
    for (const col of mapping.columns) {
      if (col.type === "number" || col.type === "currency") {
        totals[col.field] = rows.reduce((s, r) => s + (Number(r[col.field]) || 0), 0);
      }
    }
    const ctr = totals.impressions > 0 ? totals.clicks / totals.impressions * 100 : 0;
    return {
      current: { ...totals, ctr },
      previous: {},
      campaigns: rows
    };
  }
  if (source === "servicetitan") {
    const filtered = rows.filter((r) => String(r.campaign_name || "").startsWith("RS - "));
    const totalJobsBooked = filtered.reduce((s, r) => s + (Number(r.jobs_booked) || 0), 0);
    const totalJobsNew = filtered.reduce((s, r) => s + (Number(r.jobs_booked_new) || 0), 0);
    const totalJobsExisting = filtered.reduce((s, r) => s + (Number(r.jobs_booked_existing) || 0), 0);
    const completedRevenue = filtered.reduce((s, r) => s + (Number(r.completed_revenue) || 0), 0);
    const totalSales = filtered.reduce((s, r) => s + (Number(r.total_sales) || 0), 0);
    const avgConversionRate = filtered.length > 0 ? filtered.reduce((s, r) => s + (Number(r.opportunity_conversion_rate) || 0), 0) / filtered.length : 0;
    const avgRevenuePerLead = filtered.length > 0 ? filtered.reduce((s, r) => s + (Number(r.revenue_per_lead) || 0), 0) / filtered.length : 0;
    const avgJobAverage = filtered.length > 0 ? filtered.reduce((s, r) => s + (Number(r.total_job_average) || 0), 0) / filtered.length : 0;
    return {
      current: {
        totalJobsBooked,
        jobsBookedNew: totalJobsNew,
        jobsBookedExisting: totalJobsExisting,
        completedRevenue,
        totalSales,
        opportunityConversionRate: avgConversionRate,
        revenuePerLead: avgRevenuePerLead,
        totalJobAverage: avgJobAverage
      },
      previous: {},
      campaigns: filtered
    };
  }
  return { rows };
}

// netlify/functions/data-ingest-csv.ts
function parseCsvText(text) {
  const lines = text.split(/\r?\n/).filter((l) => l.trim());
  if (lines.length === 0) return { headers: [], rows: [] };
  const parseLine = (line) => {
    const result = [];
    let current = "";
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (inQuotes) {
        if (ch === '"' && line[i + 1] === '"') {
          current += '"';
          i++;
        } else if (ch === '"') {
          inQuotes = false;
        } else {
          current += ch;
        }
      } else {
        if (ch === '"') {
          inQuotes = true;
        } else if (ch === ",") {
          result.push(current.trim());
          current = "";
        } else {
          current += ch;
        }
      }
    }
    result.push(current.trim());
    return result;
  };
  const headers = parseLine(lines[0]);
  const rows = lines.slice(1).map(parseLine);
  return { headers, rows };
}
var data_ingest_csv_default = async (request, _context) => {
  if (request.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  const token = getTokenFromHeaders(
    Object.fromEntries(request.headers.entries())
  );
  if (!token) return unauthorized();
  const payload = verifyToken(token);
  if (!payload) return unauthorized("Invalid or expired token");
  if (payload.role !== "admin") return forbidden();
  const body = await request.json();
  const { clientSlug, periodStart, source, csvText, columnMap } = body;
  if (!clientSlug || !periodStart || !source || !csvText) {
    return jsonResponse(
      { error: "clientSlug, periodStart, source, and csvText required" },
      400
    );
  }
  const sourceMapping = CSV_SOURCE_MAPPINGS[source];
  if (!sourceMapping) {
    return jsonResponse({ error: `No CSV mapping defined for source: ${source}` }, 400);
  }
  const { headers, rows: rawRows } = parseCsvText(csvText);
  if (headers.length === 0 || rawRows.length === 0) {
    return jsonResponse({ error: "CSV is empty or has no data rows" }, 400);
  }
  const mapping = {};
  if (columnMap && typeof columnMap === "object") {
    for (const [csvHeader, targetField] of Object.entries(columnMap)) {
      const colDef = sourceMapping.columns.find((c) => c.field === targetField);
      if (colDef) {
        mapping[csvHeader] = colDef;
      }
    }
  } else {
    for (let i = 0; i < Math.min(headers.length, sourceMapping.columns.length); i++) {
      mapping[headers[i]] = sourceMapping.columns[i];
    }
  }
  const mappedFields = new Set(Object.values(mapping).map((c) => c.field));
  const missingRequired = sourceMapping.columns.filter((c) => c.required && !mappedFields.has(c.field)).map((c) => c.label);
  if (missingRequired.length > 0) {
    return jsonResponse(
      { error: `Missing required columns: ${missingRequired.join(", ")}` },
      400
    );
  }
  const parsedRows = rawRows.map((row) => {
    const obj = {};
    for (let i = 0; i < headers.length; i++) {
      const colDef = mapping[headers[i]];
      if (colDef) {
        obj[colDef.field] = parseCsvValue(row[i] || "", colDef.type);
      }
    }
    return obj;
  });
  const rawData = buildRawDataFromCsv(
    source,
    parsedRows,
    sourceMapping
  );
  const clients = await sql`SELECT id FROM clients WHERE slug = ${clientSlug}`;
  if (clients.length === 0) {
    return jsonResponse({ error: "Client not found" }, 404);
  }
  const clientId = clients[0].id;
  await sql`
    INSERT INTO raw_ingestions (client_id, source, period_start, raw_data, metadata)
    VALUES (
      ${clientId},
      ${source},
      ${periodStart},
      ${JSON.stringify(rawData)}::jsonb,
      ${JSON.stringify({
    importedAt: (/* @__PURE__ */ new Date()).toISOString(),
    importType: "csv",
    filename: body.filename || "unknown.csv",
    rowCount: parsedRows.length
  })}::jsonb
    )
    ON CONFLICT (client_id, source, period_start)
    DO UPDATE SET
      raw_data = ${JSON.stringify(rawData)}::jsonb,
      metadata = ${JSON.stringify({
    importedAt: (/* @__PURE__ */ new Date()).toISOString(),
    importType: "csv",
    filename: body.filename || "unknown.csv",
    rowCount: parsedRows.length
  })}::jsonb
  `;
  return jsonResponse({
    status: "success",
    source,
    rowCount: parsedRows.length,
    fields: [...mappedFields]
  });
};
export {
  data_ingest_csv_default as default
};
