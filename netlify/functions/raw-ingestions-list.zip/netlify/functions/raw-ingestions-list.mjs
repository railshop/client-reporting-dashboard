
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/db.ts
import { neon } from "@neondatabase/serverless";
var sql = neon(process.env.DATABASE_URL);

// netlify/functions/_shared/auth-middleware.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function getTokenFromHeaders(headers) {
  const auth = headers["authorization"] || headers["Authorization"];
  if (!auth?.startsWith("Bearer ")) return null;
  return auth.slice(7);
}
function unauthorized(message = "Unauthorized") {
  return new Response(JSON.stringify({ error: message }), {
    status: 401,
    headers: { "Content-Type": "application/json" }
  });
}
function forbidden(message = "Forbidden") {
  return new Response(JSON.stringify({ error: message }), {
    status: 403,
    headers: { "Content-Type": "application/json" }
  });
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// netlify/functions/raw-ingestions-list.ts
var raw_ingestions_list_default = async (request, _context) => {
  if (request.method !== "GET") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  const token = getTokenFromHeaders(
    Object.fromEntries(request.headers.entries())
  );
  if (!token) return unauthorized();
  const payload = verifyToken(token);
  if (!payload) return unauthorized("Invalid or expired token");
  if (payload.role !== "admin") return forbidden();
  const url = new URL(request.url);
  const clientSlug = url.searchParams.get("clientSlug");
  const periodStart = url.searchParams.get("periodStart");
  if (!clientSlug || !periodStart) {
    return jsonResponse({ error: "clientSlug and periodStart required" }, 400);
  }
  const clients = await sql`SELECT id FROM clients WHERE slug = ${clientSlug}`;
  if (clients.length === 0) {
    return jsonResponse({ error: "Client not found" }, 404);
  }
  const ingestions = await sql`
    SELECT id, source, raw_data, metadata, created_at
    FROM raw_ingestions
    WHERE client_id = ${clients[0].id} AND period_start = ${periodStart}
    ORDER BY source
  `;
  return jsonResponse({ ingestions });
};
export {
  raw_ingestions_list_default as default
};
