
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/db.ts
import { neon } from "@neondatabase/serverless";
var sql = neon(process.env.DATABASE_URL);

// netlify/functions/_shared/auth-middleware.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function getTokenFromHeaders(headers) {
  const auth = headers["authorization"] || headers["Authorization"];
  if (!auth?.startsWith("Bearer ")) return null;
  return auth.slice(7);
}
function unauthorized(message = "Unauthorized") {
  return new Response(JSON.stringify({ error: message }), {
    status: 401,
    headers: { "Content-Type": "application/json" }
  });
}
function forbidden(message = "Forbidden") {
  return new Response(JSON.stringify({ error: message }), {
    status: 403,
    headers: { "Content-Type": "application/json" }
  });
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// netlify/functions/report-create.ts
var report_create_default = async (request, _context) => {
  if (request.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  const token = getTokenFromHeaders(
    Object.fromEntries(request.headers.entries())
  );
  if (!token) return unauthorized();
  const payload = verifyToken(token);
  if (!payload) return unauthorized("Invalid or expired token");
  if (payload.role !== "admin") return forbidden();
  const body = await request.json();
  const { clientSlug, periodStart } = body;
  if (!clientSlug || !periodStart) {
    return jsonResponse({ error: "clientSlug and periodStart (YYYY-MM-DD) required" }, 400);
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(periodStart)) {
    return jsonResponse({ error: "periodStart must be YYYY-MM-DD format" }, 400);
  }
  const clients = await sql`SELECT id FROM clients WHERE slug = ${clientSlug}`;
  if (clients.length === 0) {
    return jsonResponse({ error: "Client not found" }, 404);
  }
  const clientId = clients[0].id;
  const existing = await sql`
    SELECT id, status FROM report_periods
    WHERE client_id = ${clientId} AND period_start = ${periodStart}
  `;
  if (existing.length > 0) {
    return jsonResponse({ error: "Report period already exists", period: existing[0] }, 409);
  }
  const result = await sql`
    INSERT INTO report_periods (client_id, period_start, status, overview)
    VALUES (${clientId}, ${periodStart}, 'draft', '{}')
    RETURNING id, period_start, status, overview, created_at
  `;
  return jsonResponse({ period: result[0] }, 201);
};
export {
  report_create_default as default
};
