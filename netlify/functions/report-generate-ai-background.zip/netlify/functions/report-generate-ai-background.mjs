
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/report-generate-ai-background.ts
import Anthropic from "@anthropic-ai/sdk";
import { z as z10 } from "zod";

// netlify/functions/_shared/db.ts
import { neon } from "@neondatabase/serverless";
var sql = neon(process.env.DATABASE_URL);

// netlify/functions/_shared/auth-middleware.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function getTokenFromHeaders(headers) {
  const auth = headers["authorization"] || headers["Authorization"];
  if (!auth?.startsWith("Bearer ")) return null;
  return auth.slice(7);
}
function unauthorized(message = "Unauthorized") {
  return new Response(JSON.stringify({ error: message }), {
    status: 401,
    headers: { "Content-Type": "application/json" }
  });
}
function forbidden(message = "Forbidden") {
  return new Response(JSON.stringify({ error: message }), {
    status: 403,
    headers: { "Content-Type": "application/json" }
  });
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// src/shared/schemas/sources/ga4.ts
import { z as z2 } from "zod";

// src/shared/schemas/common.ts
import { z } from "zod";
var kpiItemSchema = z.object({
  label: z.string(),
  value: z.string(),
  delta: z.string(),
  direction: z.enum(["up", "down", "neutral"]),
  color: z.enum(["blue", "green", "gold", "default"]).default("default")
});
var columnDefSchema = z.object({
  key: z.string(),
  label: z.string(),
  align: z.enum(["left", "right"]).default("left")
});
var tableDefSchema = z.object({
  title: z.string(),
  columns: z.array(columnDefSchema),
  rows: z.array(z.record(z.string(), z.union([z.string(), z.number()]))),
  footerRow: z.record(z.string(), z.union([z.string(), z.number()])).optional()
});
var overviewSchema = z.object({
  headline: z.string().optional(),
  summary: z.string().optional(),
  hero_stats: z.array(kpiItemSchema).optional(),
  platform_cards: z.array(z.object({
    platform: z.string(),
    metrics: z.array(z.object({
      label: z.string(),
      value: z.string()
    })),
    spend: z.string()
  })).optional()
});

// src/shared/schemas/sources/ga4.ts
var ga4SectionSchema = z2.object({
  kpis: z2.array(kpiItemSchema).min(1),
  tables: z2.object({
    channelBreakdown: tableDefSchema,
    topLandingPages: tableDefSchema
  })
});

// src/shared/schemas/sources/gsc.ts
import { z as z3 } from "zod";
var gscSectionSchema = z3.object({
  kpis: z3.array(kpiItemSchema).min(1),
  tables: z3.object({
    topQueries: tableDefSchema,
    topPages: tableDefSchema,
    positionDistribution: tableDefSchema.optional(),
    deviceBreakdown: tableDefSchema.optional()
  })
});

// src/shared/schemas/sources/google-ads.ts
import { z as z4 } from "zod";
var googleAdsSectionSchema = z4.object({
  kpis: z4.array(kpiItemSchema).min(1),
  tables: z4.object({
    assetGroupPerformance: tableDefSchema.optional()
  })
});
var googleAdsCampaignSchema = z4.object({
  campaign_name: z4.string(),
  campaign_type: z4.string(),
  metrics: z4.object({
    impressions: z4.number(),
    clicks: z4.number(),
    ctr: z4.string(),
    cpc: z4.string(),
    conversions: z4.number(),
    cost_per_conversion: z4.string(),
    spend: z4.string(),
    roas: z4.string().optional()
  })
});

// src/shared/schemas/sources/meta.ts
import { z as z5 } from "zod";
var metaSectionSchema = z5.object({
  kpis: z5.array(kpiItemSchema).min(1),
  tables: z5.object({
    creativeBreakdown: tableDefSchema.optional()
  })
});
var metaCampaignSchema = z5.object({
  campaign_name: z5.string(),
  campaign_type: z5.string(),
  metrics: z5.object({
    reach: z5.number(),
    frequency: z5.string(),
    impressions: z5.number(),
    clicks: z5.number(),
    ctr: z5.string(),
    leads: z5.number(),
    cpl: z5.string(),
    spend: z5.string()
  })
});

// src/shared/schemas/sources/lsa.ts
import { z as z6 } from "zod";
var lsaSectionSchema = z6.object({
  kpis: z6.array(kpiItemSchema).min(1),
  tables: z6.object({}).optional()
});

// src/shared/schemas/sources/servicetitan.ts
import { z as z7 } from "zod";
var servicetitanSectionSchema = z7.object({
  kpis: z7.array(kpiItemSchema).min(1),
  tables: z7.object({
    campaignPerformance: tableDefSchema.optional()
  })
});

// src/shared/schemas/sources/gbp.ts
import { z as z8 } from "zod";
var gbpSectionSchema = z8.object({
  kpis: z8.array(kpiItemSchema).min(1),
  tables: z8.object({
    searchQueries: tableDefSchema.optional(),
    photoViews: tableDefSchema.optional()
  })
});

// src/shared/schemas/sources/index.ts
var SOURCE_LABELS = {
  ga4: "Website",
  gsc: "SEO",
  google_ads: "Google Ads",
  meta: "Meta",
  lsa: "LSA",
  servicetitan: "ServiceTitan",
  gbp: "Google Business"
};

// netlify/functions/_shared/ai-prompts.ts
var AI_REPORT_SYSTEM_PROMPT = `You are a senior digital marketing analyst at Railshop, a marketing agency. You write the narrative portions of monthly performance reports \u2014 the overview and per-section analysis. KPIs, tables, and campaign data are already computed mechanically; you receive them as context.

Your output must be valid JSON matching the exact schema below. Do NOT include any text outside the JSON object. Do NOT wrap in markdown code fences.

## Output Schema

{
  "overview": {
    "headline": "string \u2014 one-line performance summary for the month",
    "summary": "string \u2014 2-3 paragraph executive summary. Professional, data-driven, actionable. Reference specific numbers and trends. Highlight wins and flag concerns.",
    "hero_stats": [
      {
        "label": "string \u2014 metric name (e.g. 'Total Leads', 'Total Spend')",
        "value": "string \u2014 formatted value (e.g. '1,234', '$5,678.90')",
        "delta": "string \u2014 period-over-period change (e.g. '+12.5%', '-3.2%', 'N/A')",
        "direction": "'up' | 'down' | 'neutral'"
      }
    ],
    "platform_cards": [
      {
        "platform": "string \u2014 source label",
        "metrics": [{ "label": "string", "value": "string" }],
        "spend": "string \u2014 formatted spend or 'N/A'"
      }
    ]
  },
  "sections": {
    "<source>": {
      "railshop_notes": "string \u2014 2-3 paragraph analysis for this source. Professional prose, no bullet points.",
      "next_priorities": ["string \u2014 actionable next step"]
    }
  }
}

## Rules

1. The overview hero_stats should aggregate across all sources \u2014 pick 3-5 cross-platform metrics that matter most (e.g. Total Leads, Total Spend, Website Sessions). Format values with commas for thousands, $ for currency, % for percentages.
2. Delta values must include a sign prefix: "+12.5%" or "-3.2%". Use "N/A" when there's no previous data.
3. Direction must be "up" if current > previous, "down" if current < previous, "neutral" if equal or N/A.
4. The overview platform_cards should have one entry per source with 2-3 key metrics each.
5. Only include sections entries for sources that have data provided.
6. Notes should be insightful \u2014 identify trends, anomalies, and opportunities. Don't just restate the numbers.
7. Next priorities should be specific and actionable (e.g. "Pause underperforming Meta campaign 'Brand Awareness Q1' \u2014 CPL is 3x above target").`;
function buildRawDataContext(ingestions, previousIngestions, mechanicalSections) {
  let context = "";
  for (const ing of ingestions) {
    const sourceLabel = SOURCE_LABELS[ing.source] || ing.source;
    context += `
## ${sourceLabel} (${ing.source}) \u2014 Current Period
`;
    context += JSON.stringify(ing.raw_data, null, 2) + "\n";
    const prev = previousIngestions.find((p) => p.source === ing.source);
    if (prev) {
      context += `
## ${sourceLabel} (${ing.source}) \u2014 Previous Period
`;
      context += JSON.stringify(prev.raw_data, null, 2) + "\n";
    }
    const mechanical = mechanicalSections?.find((s) => s.source === ing.source);
    if (mechanical) {
      context += `
## ${sourceLabel} (${ing.source}) \u2014 Computed KPIs
`;
      context += JSON.stringify(mechanical.kpis, null, 2) + "\n";
      if (mechanical.campaigns?.length) {
        context += `
## ${sourceLabel} (${ing.source}) \u2014 Campaigns
`;
        context += JSON.stringify(mechanical.campaigns, null, 2) + "\n";
      }
    }
  }
  return context;
}

// src/shared/schemas/credentials.ts
import { z as z9 } from "zod";
var ga4CredentialsSchema = z9.object({
  service_account_json: z9.string().min(1),
  property_id: z9.string().min(1)
});
var gscCredentialsSchema = z9.object({
  service_account_json: z9.string().min(1),
  site_url: z9.string().min(1)
});
var googleAdsCredentialsSchema = z9.object({
  client_id: z9.string().min(1),
  client_secret: z9.string().min(1),
  developer_token: z9.string().min(1),
  refresh_token: z9.string().min(1),
  customer_id: z9.string().min(1),
  manager_account_id: z9.string().min(1)
});
var metaCredentialsSchema = z9.object({
  access_token: z9.string().min(1),
  ad_account_id: z9.string().min(1)
});
var lsaCredentialsSchema = z9.object({});
var servicetitanCredentialsSchema = z9.object({});
var gbpCredentialsSchema = z9.object({
  service_account_json: z9.string().min(1),
  account_id: z9.string().min(1),
  location_id: z9.string().min(1)
});

// netlify/functions/_shared/data-pull-utils.ts
function getPreviousDateRange(periodStart) {
  const start = /* @__PURE__ */ new Date(periodStart + "T00:00:00");
  const year = start.getFullYear() - 1;
  const month = start.getMonth();
  const endDay = new Date(year, month + 1, 0).getDate();
  const startDate = `${year}-${String(month + 1).padStart(2, "0")}-01`;
  const endDate = `${year}-${String(month + 1).padStart(2, "0")}-${String(endDay).padStart(2, "0")}`;
  return { startDate, endDate };
}
function formatNumber(n) {
  return n.toLocaleString("en-US");
}
function formatPercent(n) {
  return n.toFixed(1) + "%";
}
function calcDelta(current, previous) {
  if (previous === 0) return { delta: "N/A", direction: "neutral" };
  const pct = (current - previous) / previous * 100;
  const sign = pct >= 0 ? "+" : "";
  return {
    delta: `${sign}${pct.toFixed(1)}%`,
    direction: pct > 0 ? "up" : pct < 0 ? "down" : "neutral"
  };
}

// netlify/functions/_shared/servicetitan-channel-map.ts
function mapCampaignToChannel(campaignName) {
  const parts = campaignName.split(" - ");
  if (parts.length < 2 || parts[0].trim() !== "RS") return null;
  const channel = parts[1].trim().toLowerCase();
  if (channel === "google ads" || channel === "ppc" || channel === "sem") return "google_ads";
  if (channel === "lsa" || channel === "local services") return "lsa";
  if (channel === "seo" || channel === "website" || channel === "organic") return "ga4";
  if (channel === "meta" || channel === "facebook") return "meta";
  if (channel === "gbp" || channel === "google business") return "gbp";
  return null;
}
function computeChannelRollups(rawCampaigns) {
  const groups = {};
  for (const c of rawCampaigns) {
    const channel = mapCampaignToChannel(c.campaign_name);
    if (!channel) continue;
    if (!groups[channel]) groups[channel] = [];
    groups[channel].push(c);
  }
  const fmtCompact$ = (v) => {
    if (v >= 1e6) return "$" + (v / 1e6).toFixed(1) + "M";
    if (v >= 1e4) return "$" + (v / 1e3).toFixed(1) + "k";
    return "$" + v.toLocaleString("en-US", { minimumFractionDigits: 2 });
  };
  const rollups = {};
  for (const [channel, campaigns] of Object.entries(groups)) {
    const totalJobs = campaigns.reduce((s, c) => s + (c.jobs_booked || 0), 0);
    const totalNew = campaigns.reduce((s, c) => s + (c.jobs_booked_new || 0), 0);
    const totalExisting = campaigns.reduce((s, c) => s + (c.jobs_booked_existing || 0), 0);
    const totalRevenue = campaigns.reduce((s, c) => s + (c.completed_revenue || 0), 0);
    const totalSales = campaigns.reduce((s, c) => s + (c.total_sales || 0), 0);
    rollups[channel] = {
      kpis: [
        { label: "Total Jobs", value: formatNumber(totalJobs), color: "default" },
        { label: "New Customers", value: formatNumber(totalNew), color: "default" },
        { label: "Existing Customers", value: formatNumber(totalExisting), color: "default" },
        { label: "Completed Revenue", value: fmtCompact$(totalRevenue), color: "default" },
        { label: "Total Sales", value: fmtCompact$(totalSales), color: "default" }
      ],
      campaigns: campaigns.sort((a, b) => (b.completed_revenue || 0) - (a.completed_revenue || 0)).map((c) => ({
        campaign: c.campaign_name,
        jobs_booked: String(c.jobs_booked || 0),
        new_customers: String(c.jobs_booked_new || 0),
        existing_customers: String(c.jobs_booked_existing || 0),
        completed_revenue: fmt$(c.completed_revenue || 0),
        total_sales: fmt$(c.total_sales || 0)
      }))
    };
  }
  return rollups;
}

// netlify/functions/_shared/transforms.ts
function transformGA4(raw) {
  const cur = raw.current || {};
  const prv = raw.previous || {};
  const kpis = [
    { label: "New Users", value: formatNumber(cur.newUsers || 0), ...calcDelta(cur.newUsers || 0, prv.newUsers || 0), color: "default" },
    { label: "Sessions", value: formatNumber(cur.sessions || 0), ...calcDelta(cur.sessions || 0, prv.sessions || 0), color: "default" },
    { label: "Organic Sessions", value: formatNumber(cur.organicSessions || 0), ...calcDelta(cur.organicSessions || 0, prv.organicSessions || 0), color: "default" },
    { label: "Direct Sessions", value: formatNumber(cur.directSessions || 0), ...calcDelta(cur.directSessions || 0, prv.directSessions || 0), color: "default" },
    { label: "Paid Sessions", value: formatNumber(cur.paidSessions || 0), ...calcDelta(cur.paidSessions || 0, prv.paidSessions || 0), color: "default" }
    // TODO: Add conversions KPI once GA4 conversion events are configured per client
  ];
  return {
    kpis,
    tables: {
      channelBreakdown: {
        title: "Channel Breakdown",
        columns: [
          { key: "channel", label: "Channel", align: "left" },
          { key: "sessions", label: "Sessions", align: "right" }
        ],
        rows: raw.channelBreakdown || []
      },
      topLandingPages: {
        title: "Top Landing Pages",
        columns: [
          { key: "page", label: "Page", align: "left" },
          { key: "sessions", label: "Sessions", align: "right" }
        ],
        rows: raw.topLandingPages || []
      }
    }
  };
}
function transformGSC(raw) {
  const cur = raw.current;
  const prv = raw.previous;
  const kpis = [
    { label: "Clicks", value: formatNumber(cur.clicks), ...calcDelta(cur.clicks, prv.clicks), color: "default" },
    { label: "Impressions", value: formatNumber(cur.impressions), ...calcDelta(cur.impressions, prv.impressions), color: "default" },
    { label: "CTR", value: formatPercent(cur.ctr * 100), ...calcDelta(cur.ctr * 100, prv.ctr * 100), color: "default" },
    { label: "Avg Position", value: cur.position.toFixed(1), ...calcDelta(prv.position, cur.position), color: "default" }
  ];
  return {
    kpis,
    tables: {
      topQueries: {
        title: "Top Search Queries",
        columns: [
          { key: "query", label: "Query", align: "left" },
          { key: "clicks", label: "Clicks", align: "right" },
          { key: "impressions", label: "Impressions", align: "right" },
          { key: "ctr", label: "CTR", align: "right" },
          { key: "position", label: "Position", align: "right" }
        ],
        rows: raw.topQueries || []
      },
      topPages: {
        title: "Top Pages",
        columns: [
          { key: "page", label: "Page", align: "left" },
          { key: "clicks", label: "Clicks", align: "right" },
          { key: "impressions", label: "Impressions", align: "right" },
          { key: "ctr", label: "CTR", align: "right" }
        ],
        rows: raw.topPages || []
      }
    }
  };
}
function transformGoogleAds(raw) {
  const cur = raw.current;
  const prv = raw.previous;
  const kpis = [
    { label: "Impressions", value: formatNumber(cur.impressions), ...calcDelta(cur.impressions, prv.impressions), color: "default" },
    { label: "Clicks", value: formatNumber(cur.clicks), ...calcDelta(cur.clicks, prv.clicks), color: "default" },
    { label: "Conversions", value: formatNumber(cur.conversions), ...calcDelta(cur.conversions, prv.conversions), color: "default" },
    { label: "Spend", value: "$" + cur.spend.toFixed(2), ...calcDelta(cur.costMicros, prv.costMicros), color: "default" },
    { label: "Cost/Conv", value: "$" + (cur.conversions > 0 ? (cur.spend / cur.conversions).toFixed(2) : "0.00"), ...calcDelta(prv.costPerConversion, cur.costPerConversion), color: "default" }
  ];
  const campaigns = (raw.campaigns || []).map((c) => {
    const spend = c.costMicros / 1e6;
    return {
      campaign_name: c.name,
      campaign_type: c.channelType,
      metrics: {
        impressions: c.impressions,
        clicks: c.clicks,
        conversions: c.conversions,
        cost_per_conversion: "$" + (c.conversions > 0 ? (spend / c.conversions).toFixed(2) : "0.00"),
        spend: "$" + spend.toFixed(2)
      }
    };
  });
  return { kpis, tables: {}, campaigns };
}
function transformMeta(raw) {
  const cur = raw.current;
  const prv = raw.previous;
  const kpis = [
    { label: "Reach", value: formatNumber(cur.reach), ...calcDelta(cur.reach, prv.reach), color: "default" },
    { label: "Impressions", value: formatNumber(cur.impressions), ...calcDelta(cur.impressions, prv.impressions), color: "default" },
    { label: "Clicks", value: formatNumber(cur.clicks), ...calcDelta(cur.clicks, prv.clicks), color: "default" },
    { label: "CTR", value: formatPercent(cur.ctr), ...calcDelta(cur.ctr, prv.ctr), color: "default" },
    { label: "Leads", value: formatNumber(cur.leads), ...calcDelta(cur.leads, prv.leads), color: "default" },
    { label: "CPL", value: cur.leads > 0 ? "$" + (cur.spend / cur.leads).toFixed(2) : "N/A", ...calcDelta(prv.cpl, cur.cpl), color: "default" },
    { label: "Spend", value: "$" + cur.spend.toFixed(2), ...calcDelta(cur.spend, prv.spend), color: "default" }
  ];
  const campaigns = (raw.campaigns || []).map((c) => ({
    campaign_name: c.campaign_name,
    campaign_type: "Meta",
    metrics: {
      reach: c.reach,
      frequency: c.frequency.toFixed(2),
      impressions: c.impressions,
      clicks: c.clicks,
      ctr: formatPercent(c.ctr),
      leads: c.leads,
      cpl: c.leads > 0 ? "$" + (c.spend / c.leads).toFixed(2) : "N/A",
      spend: "$" + c.spend.toFixed(2)
    }
  }));
  return { kpis, tables: {}, campaigns };
}
function transformServiceTitan(raw) {
  const cur = raw.current || {};
  const fmt$2 = (v) => "$" + (v || 0).toLocaleString("en-US", { minimumFractionDigits: 2 });
  const fmtCompact$ = (v) => {
    if (v >= 1e6) return "$" + (v / 1e6).toFixed(1) + "M";
    if (v >= 1e4) return "$" + (v / 1e3).toFixed(1) + "k";
    return "$" + (v || 0).toLocaleString("en-US", { minimumFractionDigits: 2 });
  };
  const kpis = [
    { label: "Jobs Booked", value: formatNumber(cur.totalJobsBooked || 0), color: "default" },
    { label: "New Customers", value: formatNumber(cur.jobsBookedNew || 0), color: "default" },
    { label: "Existing Customers", value: formatNumber(cur.jobsBookedExisting || 0), color: "default" },
    { label: "Completed Revenue", value: fmtCompact$(cur.completedRevenue || 0), color: "default" },
    { label: "Total Sales", value: fmtCompact$(cur.totalSales || 0), color: "default" },
    { label: "Conversion Rate", value: formatPercent((cur.opportunityConversionRate || 0) * 100), color: "default" },
    { label: "Revenue / Lead", value: fmt$2(cur.revenuePerLead || 0), color: "default" },
    { label: "Avg Job Total", value: fmt$2(cur.totalJobAverage || 0), color: "default" }
  ];
  const rawCampaigns = raw.campaigns || [];
  const campaigns = rawCampaigns.sort((a, b) => (Number(b.completed_revenue) || 0) - (Number(a.completed_revenue) || 0)).map((c) => ({
    campaign: String(c.campaign_name || ""),
    jobs_booked: String(c.jobs_booked || 0),
    new_customers: String(c.jobs_booked_new || 0),
    existing_customers: String(c.jobs_booked_existing || 0),
    completed_revenue: fmt$2(Number(c.completed_revenue) || 0),
    total_sales: fmt$2(Number(c.total_sales) || 0)
  }));
  const channelRollups = computeChannelRollups(
    rawCampaigns.map((c) => ({
      campaign_name: String(c.campaign_name || ""),
      jobs_booked: Number(c.jobs_booked) || 0,
      jobs_booked_new: Number(c.jobs_booked_new) || 0,
      jobs_booked_existing: Number(c.jobs_booked_existing) || 0,
      completed_revenue: Number(c.completed_revenue) || 0,
      total_sales: Number(c.total_sales) || 0
    }))
  );
  return {
    kpis,
    tables: {
      campaignPerformance: {
        title: "Campaign Performance",
        columns: [
          { key: "campaign", label: "Campaign", align: "left" },
          { key: "jobs_booked", label: "Jobs", align: "right" },
          { key: "new_customers", label: "New", align: "right" },
          { key: "existing_customers", label: "Existing", align: "right" },
          { key: "completed_revenue", label: "Revenue", align: "right" },
          { key: "total_sales", label: "Sales", align: "right" }
        ],
        rows: campaigns
      }
    },
    channelRollups: Object.keys(channelRollups).length > 0 ? channelRollups : void 0
  };
}
function transformLSA(raw) {
  const cur = raw.current || {};
  const prv = raw.previous || {};
  const kpis = [
    { label: "Leads", value: formatNumber(cur.leads || 0), ...calcDelta(cur.leads || 0, prv.leads || 0), color: "default" },
    { label: "Impressions", value: formatNumber(cur.impressions || 0), ...calcDelta(cur.impressions || 0, prv.impressions || 0), color: "default" },
    { label: "Impression \u2192 Lead", value: formatPercent(cur.impressionToLeadRate || 0), ...calcDelta(cur.impressionToLeadRate || 0, prv.impressionToLeadRate || 0), color: "default" },
    { label: "Absolute Top Rate", value: formatPercent(cur.absoluteTopRate || 0), ...calcDelta(cur.absoluteTopRate || 0, prv.absoluteTopRate || 0), color: "default" },
    { label: "Spend", value: "$" + (cur.spend || 0).toFixed(2), ...calcDelta(cur.spend || 0, prv.spend || 0), color: "default" }
  ];
  return { kpis, tables: {} };
}
function transformGBP(raw) {
  const cur = raw.current;
  const prv = raw.previous;
  const kpis = [
    { label: "Total Views", value: formatNumber(cur.totalImpressions), ...calcDelta(cur.totalImpressions, prv.totalImpressions), color: "default" },
    { label: "Maps Views", value: formatNumber(cur.mapsImpressions), ...calcDelta(cur.mapsImpressions, prv.mapsImpressions), color: "default" },
    { label: "Search Views", value: formatNumber(cur.searchImpressions), ...calcDelta(cur.searchImpressions, prv.searchImpressions), color: "default" },
    { label: "Phone Calls", value: formatNumber(cur.calls), ...calcDelta(cur.calls, prv.calls), color: "default" },
    { label: "Website Clicks", value: formatNumber(cur.websiteClicks), ...calcDelta(cur.websiteClicks, prv.websiteClicks), color: "default" },
    { label: "Direction Requests", value: formatNumber(cur.directions), ...calcDelta(cur.directions, prv.directions), color: "default" }
  ];
  return { kpis, tables: {} };
}
var transformFunctions = {
  ga4: transformGA4,
  gsc: transformGSC,
  google_ads: transformGoogleAds,
  meta: transformMeta,
  servicetitan: transformServiceTitan,
  gbp: transformGBP,
  lsa: transformLSA
};
function transformRawData(source, rawData) {
  const fn = transformFunctions[source];
  if (!fn) return null;
  return fn(rawData);
}

// netlify/functions/report-generate-ai-background.ts
var aiReportOutputSchema = z10.object({
  overview: z10.object({
    headline: z10.string().optional(),
    summary: z10.string().optional(),
    hero_stats: z10.array(kpiItemSchema).optional(),
    platform_cards: z10.array(z10.object({
      platform: z10.string(),
      metrics: z10.array(z10.object({ label: z10.string(), value: z10.string() })),
      spend: z10.string()
    })).optional()
  }),
  sections: z10.record(z10.string(), z10.object({
    railshop_notes: z10.string().optional(),
    next_priorities: z10.array(z10.string()).default([])
  }))
});
var report_generate_ai_background_default = async (request, _context) => {
  if (request.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  const token = getTokenFromHeaders(
    Object.fromEntries(request.headers.entries())
  );
  if (!token) return unauthorized();
  const payload = verifyToken(token);
  if (!payload) return unauthorized("Invalid or expired token");
  if (payload.role !== "admin") return forbidden();
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return jsonResponse({ error: "ANTHROPIC_API_KEY not configured" }, 500);
  }
  const body = await request.json();
  const { clientSlug, periodStart, prompt } = body;
  if (!clientSlug || !periodStart) {
    return jsonResponse({ error: "clientSlug and periodStart required" }, 400);
  }
  const clients = await sql`SELECT id, name FROM clients WHERE slug = ${clientSlug}`;
  if (clients.length === 0) {
    return jsonResponse({ error: "Client not found" }, 404);
  }
  const clientId = clients[0].id;
  const clientName = clients[0].name;
  let reportPeriod;
  const existing = await sql`
    SELECT id FROM report_periods
    WHERE client_id = ${clientId} AND period_start = ${periodStart}
  `;
  if (existing.length > 0) {
    reportPeriod = existing[0];
  } else {
    const created = await sql`
      INSERT INTO report_periods (client_id, period_start, status)
      VALUES (${clientId}, ${periodStart}, 'draft')
      RETURNING id
    `;
    reportPeriod = created[0];
  }
  await sql`
    UPDATE report_periods
    SET ai_status = 'pending', ai_error = NULL, updated_at = now()
    WHERE id = ${reportPeriod.id}
  `;
  try {
    await sql`
      UPDATE report_periods SET ai_status = 'generating', updated_at = now()
      WHERE id = ${reportPeriod.id}
    `;
    const ingestions = await sql`
      SELECT source, raw_data
      FROM raw_ingestions
      WHERE client_id = ${clientId} AND period_start = ${periodStart}
    `;
    if (ingestions.length === 0) {
      await sql`
        UPDATE report_periods
        SET ai_status = 'error', ai_error = 'No ingested data found. Run data ingestion first.', updated_at = now()
        WHERE id = ${reportPeriod.id}
      `;
      return new Response();
    }
    const mechanicalSections = [];
    for (const ingestion of ingestions) {
      const source = ingestion.source;
      const rawData = ingestion.raw_data;
      const data = transformRawData(source, rawData);
      if (!data) continue;
      mechanicalSections.push({
        source,
        kpis: data.kpis,
        tables: data.tables,
        campaigns: data.campaigns
      });
      const tablesToStore = {
        ...data.tables || {},
        ...data.channelRollups ? { _channelRollups: data.channelRollups } : {}
      };
      const sectionResult = await sql`
        INSERT INTO report_sections (report_period_id, source, kpis, tables)
        VALUES (
          ${reportPeriod.id},
          ${source},
          ${JSON.stringify(data.kpis)}::jsonb,
          ${JSON.stringify(tablesToStore)}::jsonb
        )
        ON CONFLICT (report_period_id, source)
        DO UPDATE SET
          kpis = ${JSON.stringify(data.kpis)}::jsonb,
          tables = ${JSON.stringify(tablesToStore)}::jsonb,
          updated_at = now()
        RETURNING id
      `;
      if (data.campaigns?.length) {
        const sectionId = sectionResult[0].id;
        await sql`DELETE FROM campaign_metrics WHERE report_section_id = ${sectionId}`;
        for (const c of data.campaigns) {
          await sql`
            INSERT INTO campaign_metrics (report_section_id, campaign_name, campaign_type, metrics)
            VALUES (${sectionId}, ${c.campaign_name}, ${c.campaign_type || null}, ${JSON.stringify(c.metrics)}::jsonb)
          `;
        }
      }
    }
    const prev = getPreviousDateRange(periodStart);
    const previousIngestions = await sql`
      SELECT source, raw_data
      FROM raw_ingestions
      WHERE client_id = ${clientId} AND period_start = ${prev.startDate}
    `;
    const dataContext = buildRawDataContext(
      ingestions,
      previousIngestions,
      mechanicalSections
    );
    let userMessage = `Generate the narrative portions of the monthly performance report for ${clientName}.
Period: ${periodStart}

Raw data and computed KPIs:
${dataContext}`;
    if (prompt) {
      userMessage += `

Admin guidance: ${prompt}`;
    }
    const client = new Anthropic({ apiKey });
    const response = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 4096,
      system: AI_REPORT_SYSTEM_PROMPT,
      messages: [{ role: "user", content: userMessage }]
    });
    const textBlock = response.content.find((b) => b.type === "text");
    const rawOutput = textBlock?.text || "";
    let parsed;
    try {
      let jsonStr = rawOutput.trim();
      jsonStr = jsonStr.replace(/^```(?:json)?\s*\n?/, "");
      jsonStr = jsonStr.replace(/\n?```\s*$/, "");
      jsonStr = jsonStr.trim();
      parsed = JSON.parse(jsonStr);
    } catch (parseErr) {
      console.error("[ai-background] JSON parse failed. First 500 chars:", rawOutput.slice(0, 500));
      await sql`
        UPDATE report_periods
        SET ai_status = 'error', ai_error = ${"Claude returned invalid JSON: " + (parseErr.message || "")}, updated_at = now()
        WHERE id = ${reportPeriod.id}
      `;
      return new Response();
    }
    const validation = aiReportOutputSchema.safeParse(parsed);
    if (!validation.success) {
      await sql`
        UPDATE report_periods
        SET ai_status = 'error', ai_error = ${"Schema validation failed: " + JSON.stringify(validation.error.issues.slice(0, 3))}, updated_at = now()
        WHERE id = ${reportPeriod.id}
      `;
      return new Response();
    }
    const reportData = validation.data;
    await sql`
      UPDATE report_periods SET
        overview = ${JSON.stringify(reportData.overview)}::jsonb,
        updated_at = now()
      WHERE id = ${reportPeriod.id}
    `;
    for (const [source, narrative] of Object.entries(reportData.sections)) {
      await sql`
        UPDATE report_sections SET
          railshop_notes = ${narrative.railshop_notes || null},
          next_priorities = ${narrative.next_priorities.length > 0 ? narrative.next_priorities : null},
          updated_at = now()
        WHERE report_period_id = ${reportPeriod.id} AND source = ${source}
      `;
    }
    await sql`
      UPDATE report_periods
      SET ai_status = 'complete', ai_error = NULL, updated_at = now()
      WHERE id = ${reportPeriod.id}
    `;
  } catch (err) {
    await sql`
      UPDATE report_periods
      SET ai_status = 'error', ai_error = ${err.message || "AI generation failed"}, updated_at = now()
      WHERE id = ${reportPeriod.id}
    `;
  }
  return new Response();
};
export {
  report_generate_ai_background_default as default
};
