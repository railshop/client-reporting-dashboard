
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/db.ts
import { neon } from "@neondatabase/serverless";
var sql = neon(process.env.DATABASE_URL);

// netlify/functions/_shared/auth-middleware.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function getTokenFromHeaders(headers) {
  const auth = headers["authorization"] || headers["Authorization"];
  if (!auth?.startsWith("Bearer ")) return null;
  return auth.slice(7);
}
function unauthorized(message = "Unauthorized") {
  return new Response(JSON.stringify({ error: message }), {
    status: 401,
    headers: { "Content-Type": "application/json" }
  });
}
function forbidden(message = "Forbidden") {
  return new Response(JSON.stringify({ error: message }), {
    status: 403,
    headers: { "Content-Type": "application/json" }
  });
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// src/shared/schemas/credentials.ts
import { z } from "zod";
var ga4CredentialsSchema = z.object({
  service_account_json: z.string().min(1),
  property_id: z.string().min(1)
});
var gscCredentialsSchema = z.object({
  service_account_json: z.string().min(1),
  site_url: z.string().min(1)
});
var googleAdsCredentialsSchema = z.object({
  client_id: z.string().min(1),
  client_secret: z.string().min(1),
  developer_token: z.string().min(1),
  refresh_token: z.string().min(1),
  customer_id: z.string().min(1),
  manager_account_id: z.string().min(1)
});
var metaCredentialsSchema = z.object({
  access_token: z.string().min(1),
  ad_account_id: z.string().min(1)
});
var lsaCredentialsSchema = z.object({});
var servicetitanCredentialsSchema = z.object({});
var gbpCredentialsSchema = z.object({
  service_account_json: z.string().min(1),
  account_id: z.string().min(1),
  location_id: z.string().min(1)
});

// netlify/functions/_shared/data-pull-utils.ts
function formatNumber(n) {
  return n.toLocaleString("en-US");
}
function formatPercent(n) {
  return n.toFixed(1) + "%";
}
function calcDelta(current, previous) {
  if (previous === 0) return { delta: "N/A", direction: "neutral" };
  const pct = (current - previous) / previous * 100;
  const sign = pct >= 0 ? "+" : "";
  return {
    delta: `${sign}${pct.toFixed(1)}%`,
    direction: pct > 0 ? "up" : pct < 0 ? "down" : "neutral"
  };
}

// netlify/functions/_shared/servicetitan-channel-map.ts
function mapCampaignToChannel(campaignName) {
  const parts = campaignName.split(" - ");
  if (parts.length < 2 || parts[0].trim() !== "RS") return null;
  const channel = parts[1].trim().toLowerCase();
  if (channel === "google ads" || channel === "ppc" || channel === "sem") return "google_ads";
  if (channel === "lsa" || channel === "local services") return "lsa";
  if (channel === "seo" || channel === "website" || channel === "organic") return "ga4";
  if (channel === "meta" || channel === "facebook") return "meta";
  if (channel === "gbp" || channel === "google business") return "gbp";
  return null;
}
function computeChannelRollups(rawCampaigns) {
  const groups = {};
  for (const c of rawCampaigns) {
    const channel = mapCampaignToChannel(c.campaign_name);
    if (!channel) continue;
    if (!groups[channel]) groups[channel] = [];
    groups[channel].push(c);
  }
  const fmtCompact$ = (v) => {
    if (v >= 1e6) return "$" + (v / 1e6).toFixed(1) + "M";
    if (v >= 1e4) return "$" + (v / 1e3).toFixed(1) + "k";
    return "$" + v.toLocaleString("en-US", { minimumFractionDigits: 2 });
  };
  const rollups = {};
  for (const [channel, campaigns] of Object.entries(groups)) {
    const totalJobs = campaigns.reduce((s, c) => s + (c.jobs_booked || 0), 0);
    const totalNew = campaigns.reduce((s, c) => s + (c.jobs_booked_new || 0), 0);
    const totalExisting = campaigns.reduce((s, c) => s + (c.jobs_booked_existing || 0), 0);
    const totalRevenue = campaigns.reduce((s, c) => s + (c.completed_revenue || 0), 0);
    const totalSales = campaigns.reduce((s, c) => s + (c.total_sales || 0), 0);
    rollups[channel] = {
      kpis: [
        { label: "Total Jobs", value: formatNumber(totalJobs), color: "default" },
        { label: "New Customers", value: formatNumber(totalNew), color: "default" },
        { label: "Existing Customers", value: formatNumber(totalExisting), color: "default" },
        { label: "Completed Revenue", value: fmtCompact$(totalRevenue), color: "default" },
        { label: "Total Sales", value: fmtCompact$(totalSales), color: "default" }
      ],
      campaigns: campaigns.sort((a, b) => (b.completed_revenue || 0) - (a.completed_revenue || 0)).map((c) => ({
        campaign: c.campaign_name,
        jobs_booked: String(c.jobs_booked || 0),
        new_customers: String(c.jobs_booked_new || 0),
        existing_customers: String(c.jobs_booked_existing || 0),
        completed_revenue: fmt$(c.completed_revenue || 0),
        total_sales: fmt$(c.total_sales || 0)
      }))
    };
  }
  return rollups;
}

// netlify/functions/_shared/transforms.ts
function transformGA4(raw) {
  const cur = raw.current || {};
  const prv = raw.previous || {};
  const kpis = [
    { label: "New Users", value: formatNumber(cur.newUsers || 0), ...calcDelta(cur.newUsers || 0, prv.newUsers || 0), color: "default" },
    { label: "Sessions", value: formatNumber(cur.sessions || 0), ...calcDelta(cur.sessions || 0, prv.sessions || 0), color: "default" },
    { label: "Organic Sessions", value: formatNumber(cur.organicSessions || 0), ...calcDelta(cur.organicSessions || 0, prv.organicSessions || 0), color: "default" },
    { label: "Direct Sessions", value: formatNumber(cur.directSessions || 0), ...calcDelta(cur.directSessions || 0, prv.directSessions || 0), color: "default" },
    { label: "Paid Sessions", value: formatNumber(cur.paidSessions || 0), ...calcDelta(cur.paidSessions || 0, prv.paidSessions || 0), color: "default" }
    // TODO: Add conversions KPI once GA4 conversion events are configured per client
  ];
  return {
    kpis,
    tables: {
      channelBreakdown: {
        title: "Channel Breakdown",
        columns: [
          { key: "channel", label: "Channel", align: "left" },
          { key: "sessions", label: "Sessions", align: "right" }
        ],
        rows: raw.channelBreakdown || []
      },
      topLandingPages: {
        title: "Top Landing Pages",
        columns: [
          { key: "page", label: "Page", align: "left" },
          { key: "sessions", label: "Sessions", align: "right" }
        ],
        rows: raw.topLandingPages || []
      }
    }
  };
}
function transformGSC(raw) {
  const cur = raw.current;
  const prv = raw.previous;
  const kpis = [
    { label: "Clicks", value: formatNumber(cur.clicks), ...calcDelta(cur.clicks, prv.clicks), color: "default" },
    { label: "Impressions", value: formatNumber(cur.impressions), ...calcDelta(cur.impressions, prv.impressions), color: "default" },
    { label: "CTR", value: formatPercent(cur.ctr * 100), ...calcDelta(cur.ctr * 100, prv.ctr * 100), color: "default" },
    { label: "Avg Position", value: cur.position.toFixed(1), ...calcDelta(prv.position, cur.position), color: "default" }
  ];
  return {
    kpis,
    tables: {
      topQueries: {
        title: "Top Search Queries",
        columns: [
          { key: "query", label: "Query", align: "left" },
          { key: "clicks", label: "Clicks", align: "right" },
          { key: "impressions", label: "Impressions", align: "right" },
          { key: "ctr", label: "CTR", align: "right" },
          { key: "position", label: "Position", align: "right" }
        ],
        rows: raw.topQueries || []
      },
      topPages: {
        title: "Top Pages",
        columns: [
          { key: "page", label: "Page", align: "left" },
          { key: "clicks", label: "Clicks", align: "right" },
          { key: "impressions", label: "Impressions", align: "right" },
          { key: "ctr", label: "CTR", align: "right" }
        ],
        rows: raw.topPages || []
      }
    }
  };
}
function transformGoogleAds(raw) {
  const cur = raw.current;
  const prv = raw.previous;
  const kpis = [
    { label: "Impressions", value: formatNumber(cur.impressions), ...calcDelta(cur.impressions, prv.impressions), color: "default" },
    { label: "Clicks", value: formatNumber(cur.clicks), ...calcDelta(cur.clicks, prv.clicks), color: "default" },
    { label: "Conversions", value: formatNumber(cur.conversions), ...calcDelta(cur.conversions, prv.conversions), color: "default" },
    { label: "Spend", value: "$" + cur.spend.toFixed(2), ...calcDelta(cur.costMicros, prv.costMicros), color: "default" },
    { label: "Cost/Conv", value: "$" + (cur.conversions > 0 ? (cur.spend / cur.conversions).toFixed(2) : "0.00"), ...calcDelta(prv.costPerConversion, cur.costPerConversion), color: "default" }
  ];
  const campaigns = (raw.campaigns || []).map((c) => {
    const spend = c.costMicros / 1e6;
    return {
      campaign_name: c.name,
      campaign_type: c.channelType,
      metrics: {
        impressions: c.impressions,
        clicks: c.clicks,
        conversions: c.conversions,
        cost_per_conversion: "$" + (c.conversions > 0 ? (spend / c.conversions).toFixed(2) : "0.00"),
        spend: "$" + spend.toFixed(2)
      }
    };
  });
  return { kpis, tables: {}, campaigns };
}
function transformMeta(raw) {
  const cur = raw.current;
  const prv = raw.previous;
  const kpis = [
    { label: "Reach", value: formatNumber(cur.reach), ...calcDelta(cur.reach, prv.reach), color: "default" },
    { label: "Impressions", value: formatNumber(cur.impressions), ...calcDelta(cur.impressions, prv.impressions), color: "default" },
    { label: "Clicks", value: formatNumber(cur.clicks), ...calcDelta(cur.clicks, prv.clicks), color: "default" },
    { label: "CTR", value: formatPercent(cur.ctr), ...calcDelta(cur.ctr, prv.ctr), color: "default" },
    { label: "Leads", value: formatNumber(cur.leads), ...calcDelta(cur.leads, prv.leads), color: "default" },
    { label: "CPL", value: cur.leads > 0 ? "$" + (cur.spend / cur.leads).toFixed(2) : "N/A", ...calcDelta(prv.cpl, cur.cpl), color: "default" },
    { label: "Spend", value: "$" + cur.spend.toFixed(2), ...calcDelta(cur.spend, prv.spend), color: "default" }
  ];
  const campaigns = (raw.campaigns || []).map((c) => ({
    campaign_name: c.campaign_name,
    campaign_type: "Meta",
    metrics: {
      reach: c.reach,
      frequency: c.frequency.toFixed(2),
      impressions: c.impressions,
      clicks: c.clicks,
      ctr: formatPercent(c.ctr),
      leads: c.leads,
      cpl: c.leads > 0 ? "$" + (c.spend / c.leads).toFixed(2) : "N/A",
      spend: "$" + c.spend.toFixed(2)
    }
  }));
  return { kpis, tables: {}, campaigns };
}
function transformServiceTitan(raw) {
  const cur = raw.current || {};
  const fmt$2 = (v) => "$" + (v || 0).toLocaleString("en-US", { minimumFractionDigits: 2 });
  const fmtCompact$ = (v) => {
    if (v >= 1e6) return "$" + (v / 1e6).toFixed(1) + "M";
    if (v >= 1e4) return "$" + (v / 1e3).toFixed(1) + "k";
    return "$" + (v || 0).toLocaleString("en-US", { minimumFractionDigits: 2 });
  };
  const kpis = [
    { label: "Jobs Booked", value: formatNumber(cur.totalJobsBooked || 0), color: "default" },
    { label: "New Customers", value: formatNumber(cur.jobsBookedNew || 0), color: "default" },
    { label: "Existing Customers", value: formatNumber(cur.jobsBookedExisting || 0), color: "default" },
    { label: "Completed Revenue", value: fmtCompact$(cur.completedRevenue || 0), color: "default" },
    { label: "Total Sales", value: fmtCompact$(cur.totalSales || 0), color: "default" },
    { label: "Conversion Rate", value: formatPercent((cur.opportunityConversionRate || 0) * 100), color: "default" },
    { label: "Revenue / Lead", value: fmt$2(cur.revenuePerLead || 0), color: "default" },
    { label: "Avg Job Total", value: fmt$2(cur.totalJobAverage || 0), color: "default" }
  ];
  const rawCampaigns = raw.campaigns || [];
  const campaigns = rawCampaigns.sort((a, b) => (Number(b.completed_revenue) || 0) - (Number(a.completed_revenue) || 0)).map((c) => ({
    campaign: String(c.campaign_name || ""),
    jobs_booked: String(c.jobs_booked || 0),
    new_customers: String(c.jobs_booked_new || 0),
    existing_customers: String(c.jobs_booked_existing || 0),
    completed_revenue: fmt$2(Number(c.completed_revenue) || 0),
    total_sales: fmt$2(Number(c.total_sales) || 0)
  }));
  const channelRollups = computeChannelRollups(
    rawCampaigns.map((c) => ({
      campaign_name: String(c.campaign_name || ""),
      jobs_booked: Number(c.jobs_booked) || 0,
      jobs_booked_new: Number(c.jobs_booked_new) || 0,
      jobs_booked_existing: Number(c.jobs_booked_existing) || 0,
      completed_revenue: Number(c.completed_revenue) || 0,
      total_sales: Number(c.total_sales) || 0
    }))
  );
  return {
    kpis,
    tables: {
      campaignPerformance: {
        title: "Campaign Performance",
        columns: [
          { key: "campaign", label: "Campaign", align: "left" },
          { key: "jobs_booked", label: "Jobs", align: "right" },
          { key: "new_customers", label: "New", align: "right" },
          { key: "existing_customers", label: "Existing", align: "right" },
          { key: "completed_revenue", label: "Revenue", align: "right" },
          { key: "total_sales", label: "Sales", align: "right" }
        ],
        rows: campaigns
      }
    },
    channelRollups: Object.keys(channelRollups).length > 0 ? channelRollups : void 0
  };
}
function transformLSA(raw) {
  const cur = raw.current || {};
  const prv = raw.previous || {};
  const kpis = [
    { label: "Leads", value: formatNumber(cur.leads || 0), ...calcDelta(cur.leads || 0, prv.leads || 0), color: "default" },
    { label: "Impressions", value: formatNumber(cur.impressions || 0), ...calcDelta(cur.impressions || 0, prv.impressions || 0), color: "default" },
    { label: "Impression \u2192 Lead", value: formatPercent(cur.impressionToLeadRate || 0), ...calcDelta(cur.impressionToLeadRate || 0, prv.impressionToLeadRate || 0), color: "default" },
    { label: "Absolute Top Rate", value: formatPercent(cur.absoluteTopRate || 0), ...calcDelta(cur.absoluteTopRate || 0, prv.absoluteTopRate || 0), color: "default" },
    { label: "Spend", value: "$" + (cur.spend || 0).toFixed(2), ...calcDelta(cur.spend || 0, prv.spend || 0), color: "default" }
  ];
  return { kpis, tables: {} };
}
function transformGBP(raw) {
  const cur = raw.current;
  const prv = raw.previous;
  const kpis = [
    { label: "Total Views", value: formatNumber(cur.totalImpressions), ...calcDelta(cur.totalImpressions, prv.totalImpressions), color: "default" },
    { label: "Maps Views", value: formatNumber(cur.mapsImpressions), ...calcDelta(cur.mapsImpressions, prv.mapsImpressions), color: "default" },
    { label: "Search Views", value: formatNumber(cur.searchImpressions), ...calcDelta(cur.searchImpressions, prv.searchImpressions), color: "default" },
    { label: "Phone Calls", value: formatNumber(cur.calls), ...calcDelta(cur.calls, prv.calls), color: "default" },
    { label: "Website Clicks", value: formatNumber(cur.websiteClicks), ...calcDelta(cur.websiteClicks, prv.websiteClicks), color: "default" },
    { label: "Direction Requests", value: formatNumber(cur.directions), ...calcDelta(cur.directions, prv.directions), color: "default" }
  ];
  return { kpis, tables: {} };
}
var transformFunctions = {
  ga4: transformGA4,
  gsc: transformGSC,
  google_ads: transformGoogleAds,
  meta: transformMeta,
  servicetitan: transformServiceTitan,
  gbp: transformGBP,
  lsa: transformLSA
};
function transformRawData(source, rawData) {
  const fn = transformFunctions[source];
  if (!fn) return null;
  return fn(rawData);
}

// netlify/functions/report-generate.ts
var report_generate_default = async (request, _context) => {
  if (request.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  const token = getTokenFromHeaders(
    Object.fromEntries(request.headers.entries())
  );
  if (!token) return unauthorized();
  const payload = verifyToken(token);
  if (!payload) return unauthorized("Invalid or expired token");
  if (payload.role !== "admin") return forbidden();
  const body = await request.json();
  const { clientSlug, periodStart } = body;
  if (!clientSlug || !periodStart) {
    return jsonResponse({ error: "clientSlug and periodStart required" }, 400);
  }
  const clients = await sql`SELECT id FROM clients WHERE slug = ${clientSlug}`;
  if (clients.length === 0) {
    return jsonResponse({ error: "Client not found" }, 404);
  }
  const clientId = clients[0].id;
  let reportPeriod;
  const existing = await sql`
    SELECT id FROM report_periods
    WHERE client_id = ${clientId} AND period_start = ${periodStart}
  `;
  if (existing.length > 0) {
    reportPeriod = existing[0];
  } else {
    const created = await sql`
      INSERT INTO report_periods (client_id, period_start, status)
      VALUES (${clientId}, ${periodStart}, 'draft')
      RETURNING id
    `;
    reportPeriod = created[0];
  }
  const ingestions = await sql`
    SELECT source, raw_data
    FROM raw_ingestions
    WHERE client_id = ${clientId} AND period_start = ${periodStart}
  `;
  if (ingestions.length === 0) {
    return jsonResponse({ error: "No ingested data found. Run data ingestion first." }, 400);
  }
  const results = {};
  for (const ingestion of ingestions) {
    const source = ingestion.source;
    const rawData = ingestion.raw_data;
    try {
      const data = transformRawData(source, rawData);
      if (!data) {
        results[source] = { status: "skipped", error: "No transform available" };
        continue;
      }
      const tablesToStore = {
        ...data.tables || {},
        ...data.channelRollups ? { _channelRollups: data.channelRollups } : {}
      };
      const sectionResult = await sql`
        INSERT INTO report_sections (report_period_id, source, kpis, tables)
        VALUES (
          ${reportPeriod.id},
          ${source},
          ${JSON.stringify(data.kpis)}::jsonb,
          ${JSON.stringify(tablesToStore)}::jsonb
        )
        ON CONFLICT (report_period_id, source)
        DO UPDATE SET
          kpis = ${JSON.stringify(data.kpis)}::jsonb,
          tables = ${JSON.stringify(tablesToStore)}::jsonb,
          updated_at = now()
        RETURNING id
      `;
      if (data.campaigns?.length) {
        const sectionId = sectionResult[0].id;
        await sql`DELETE FROM campaign_metrics WHERE report_section_id = ${sectionId}`;
        for (const c of data.campaigns) {
          await sql`
            INSERT INTO campaign_metrics (report_section_id, campaign_name, campaign_type, metrics)
            VALUES (${sectionId}, ${c.campaign_name}, ${c.campaign_type || null}, ${JSON.stringify(c.metrics)}::jsonb)
          `;
        }
      }
      results[source] = { status: "success" };
    } catch (err) {
      results[source] = { status: "error", error: err.message || "Unknown error" };
    }
  }
  return jsonResponse({ reportPeriodId: reportPeriod.id, results });
};
export {
  report_generate_default as default
};
