
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/db.ts
import { neon } from "@neondatabase/serverless";
var sql = neon(process.env.DATABASE_URL);

// netlify/functions/_shared/auth-middleware.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function getTokenFromHeaders(headers) {
  const auth = headers["authorization"] || headers["Authorization"];
  if (!auth?.startsWith("Bearer ")) return null;
  return auth.slice(7);
}
function unauthorized(message = "Unauthorized") {
  return new Response(JSON.stringify({ error: message }), {
    status: 401,
    headers: { "Content-Type": "application/json" }
  });
}
function forbidden(message = "Forbidden") {
  return new Response(JSON.stringify({ error: message }), {
    status: 403,
    headers: { "Content-Type": "application/json" }
  });
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// netlify/functions/report-get.ts
var report_get_default = async (request, _context) => {
  const token = getTokenFromHeaders(
    Object.fromEntries(request.headers.entries())
  );
  if (!token) return unauthorized();
  const payload = verifyToken(token);
  if (!payload) return unauthorized("Invalid or expired token");
  const url = new URL(request.url);
  const clientSlug = url.searchParams.get("client");
  const period = url.searchParams.get("period");
  if (!clientSlug) {
    return jsonResponse({ error: "client query param required" }, 400);
  }
  if (payload.role === "client" && payload.clientSlug !== clientSlug) {
    return forbidden();
  }
  const clients = await sql`
    SELECT id, slug, name, logo_url FROM clients WHERE slug = ${clientSlug}
  `;
  if (clients.length === 0) {
    return jsonResponse({ error: "Client not found" }, 404);
  }
  const client = clients[0];
  const isClient = payload.role === "client";
  let periods;
  if (period) {
    const periodStart = `${period}-01`;
    periods = isClient ? await sql`
          SELECT id, period_start, status, overview, railshop_notes, next_priorities, published_at
          FROM report_periods
          WHERE client_id = ${client.id} AND period_start = ${periodStart} AND status = 'published'
        ` : await sql`
          SELECT id, period_start, status, overview, railshop_notes, next_priorities, published_at
          FROM report_periods
          WHERE client_id = ${client.id} AND period_start = ${periodStart}
        `;
  } else {
    periods = isClient ? await sql`
          SELECT id, period_start, status, overview, railshop_notes, next_priorities, published_at
          FROM report_periods
          WHERE client_id = ${client.id} AND status = 'published'
          ORDER BY period_start DESC
          LIMIT 1
        ` : await sql`
          SELECT id, period_start, status, overview, railshop_notes, next_priorities, published_at
          FROM report_periods
          WHERE client_id = ${client.id}
          ORDER BY period_start DESC
          LIMIT 1
        `;
  }
  if (periods.length === 0) {
    return jsonResponse({ error: "No report found for this period" }, 404);
  }
  const reportPeriod = periods[0];
  const sections = await sql`
    SELECT id, source, kpis, tables, railshop_notes, next_priorities
    FROM report_sections
    WHERE report_period_id = ${reportPeriod.id}
    ORDER BY source
  `;
  const sectionIds = sections.map((s) => s.id);
  let campaigns = [];
  if (sectionIds.length > 0) {
    campaigns = await sql`
      SELECT id, report_section_id, campaign_name, campaign_type, metrics
      FROM campaign_metrics
      WHERE report_section_id = ANY(${sectionIds})
      ORDER BY campaign_name
    `;
  }
  const stSection = sections.find((s) => s.source === "servicetitan");
  const channelRollups = stSection?.tables?._channelRollups || {};
  const sectionsWithCampaigns = sections.map((section) => {
    const result = {
      ...section,
      campaigns: campaigns.filter((c) => c.report_section_id === section.id)
    };
    if (section.source === "servicetitan" && result.tables?._channelRollups) {
      const { _channelRollups, ...cleanTables } = result.tables;
      result.tables = cleanTables;
    }
    if (section.source !== "servicetitan" && channelRollups[section.source]) {
      result.servicetitan_blended = channelRollups[section.source];
    }
    return result;
  });
  return jsonResponse({
    client: {
      slug: client.slug,
      name: client.name,
      logo_url: client.logo_url
    },
    period: {
      id: reportPeriod.id,
      period_start: reportPeriod.period_start,
      status: reportPeriod.status,
      overview: reportPeriod.overview,
      railshop_notes: reportPeriod.railshop_notes,
      next_priorities: reportPeriod.next_priorities,
      published_at: reportPeriod.published_at
    },
    sections: sectionsWithCampaigns
  });
};
export {
  report_get_default as default
};
