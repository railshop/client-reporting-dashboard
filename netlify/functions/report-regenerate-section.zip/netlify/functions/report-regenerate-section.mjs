
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/report-regenerate-section.ts
import Anthropic from "@anthropic-ai/sdk";
import { z as z9 } from "zod";

// netlify/functions/_shared/db.ts
import { neon } from "@neondatabase/serverless";
var sql = neon(process.env.DATABASE_URL);

// netlify/functions/_shared/auth-middleware.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function getTokenFromHeaders(headers) {
  const auth = headers["authorization"] || headers["Authorization"];
  if (!auth?.startsWith("Bearer ")) return null;
  return auth.slice(7);
}
function unauthorized(message = "Unauthorized") {
  return new Response(JSON.stringify({ error: message }), {
    status: 401,
    headers: { "Content-Type": "application/json" }
  });
}
function forbidden(message = "Forbidden") {
  return new Response(JSON.stringify({ error: message }), {
    status: 403,
    headers: { "Content-Type": "application/json" }
  });
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// src/shared/schemas/sources/ga4.ts
import { z as z2 } from "zod";

// src/shared/schemas/common.ts
import { z } from "zod";
var kpiItemSchema = z.object({
  label: z.string(),
  value: z.string(),
  delta: z.string(),
  direction: z.enum(["up", "down", "neutral"]),
  color: z.enum(["blue", "green", "gold", "default"]).default("default")
});
var columnDefSchema = z.object({
  key: z.string(),
  label: z.string(),
  align: z.enum(["left", "right"]).default("left")
});
var tableDefSchema = z.object({
  title: z.string(),
  columns: z.array(columnDefSchema),
  rows: z.array(z.record(z.string(), z.union([z.string(), z.number()]))),
  footerRow: z.record(z.string(), z.union([z.string(), z.number()])).optional()
});
var overviewSchema = z.object({
  headline: z.string().optional(),
  summary: z.string().optional(),
  hero_stats: z.array(kpiItemSchema).optional(),
  platform_cards: z.array(z.object({
    platform: z.string(),
    metrics: z.array(z.object({
      label: z.string(),
      value: z.string()
    })),
    spend: z.string()
  })).optional()
});

// src/shared/schemas/sources/ga4.ts
var ga4SectionSchema = z2.object({
  kpis: z2.array(kpiItemSchema).min(1),
  tables: z2.object({
    channelBreakdown: tableDefSchema,
    topLandingPages: tableDefSchema
  })
});

// src/shared/schemas/sources/gsc.ts
import { z as z3 } from "zod";
var gscSectionSchema = z3.object({
  kpis: z3.array(kpiItemSchema).min(1),
  tables: z3.object({
    topQueries: tableDefSchema,
    topPages: tableDefSchema,
    positionDistribution: tableDefSchema.optional(),
    deviceBreakdown: tableDefSchema.optional()
  })
});

// src/shared/schemas/sources/google-ads.ts
import { z as z4 } from "zod";
var googleAdsSectionSchema = z4.object({
  kpis: z4.array(kpiItemSchema).min(1),
  tables: z4.object({
    assetGroupPerformance: tableDefSchema.optional()
  })
});
var googleAdsCampaignSchema = z4.object({
  campaign_name: z4.string(),
  campaign_type: z4.string(),
  metrics: z4.object({
    impressions: z4.number(),
    clicks: z4.number(),
    ctr: z4.string(),
    cpc: z4.string(),
    conversions: z4.number(),
    cost_per_conversion: z4.string(),
    spend: z4.string(),
    roas: z4.string().optional()
  })
});

// src/shared/schemas/sources/meta.ts
import { z as z5 } from "zod";
var metaSectionSchema = z5.object({
  kpis: z5.array(kpiItemSchema).min(1),
  tables: z5.object({
    creativeBreakdown: tableDefSchema.optional()
  })
});
var metaCampaignSchema = z5.object({
  campaign_name: z5.string(),
  campaign_type: z5.string(),
  metrics: z5.object({
    reach: z5.number(),
    frequency: z5.string(),
    impressions: z5.number(),
    clicks: z5.number(),
    ctr: z5.string(),
    leads: z5.number(),
    cpl: z5.string(),
    spend: z5.string()
  })
});

// src/shared/schemas/sources/lsa.ts
import { z as z6 } from "zod";
var lsaSectionSchema = z6.object({
  kpis: z6.array(kpiItemSchema).min(1),
  tables: z6.object({}).optional()
});

// src/shared/schemas/sources/servicetitan.ts
import { z as z7 } from "zod";
var servicetitanSectionSchema = z7.object({
  kpis: z7.array(kpiItemSchema).min(1),
  tables: z7.object({
    campaignPerformance: tableDefSchema.optional()
  })
});

// src/shared/schemas/sources/gbp.ts
import { z as z8 } from "zod";
var gbpSectionSchema = z8.object({
  kpis: z8.array(kpiItemSchema).min(1),
  tables: z8.object({
    searchQueries: tableDefSchema.optional(),
    photoViews: tableDefSchema.optional()
  })
});

// src/shared/schemas/sources/index.ts
var SOURCE_LABELS = {
  ga4: "Website",
  gsc: "SEO",
  google_ads: "Google Ads",
  meta: "Meta",
  lsa: "LSA",
  servicetitan: "ServiceTitan",
  gbp: "Google Business"
};

// netlify/functions/_shared/ai-prompts.ts
function buildSectionDataContext(source, rawData, previousRawData, mechanicalKpis, mechanicalCampaigns) {
  const sourceLabel = SOURCE_LABELS[source] || source;
  let context = `
## ${sourceLabel} (${source}) \u2014 Current Period
`;
  context += JSON.stringify(rawData, null, 2) + "\n";
  if (previousRawData) {
    context += `
## ${sourceLabel} (${source}) \u2014 Previous Period
`;
    context += JSON.stringify(previousRawData, null, 2) + "\n";
  }
  if (mechanicalKpis) {
    context += `
## ${sourceLabel} (${source}) \u2014 Computed KPIs
`;
    context += JSON.stringify(mechanicalKpis, null, 2) + "\n";
  }
  if (mechanicalCampaigns?.length) {
    context += `
## ${sourceLabel} (${source}) \u2014 Campaigns
`;
    context += JSON.stringify(mechanicalCampaigns, null, 2) + "\n";
  }
  return context;
}
var AI_SECTION_SYSTEM_PROMPT = `You are a senior digital marketing analyst at Railshop, a marketing agency. You write the narrative analysis for a single section of a monthly performance report. KPIs, tables, and campaign data are already computed mechanically; you receive them as context.

Your output must be valid JSON matching the exact schema below. Do NOT include any text outside the JSON object. Do NOT wrap in markdown code fences.

## Output Schema

{
  "railshop_notes": "string \u2014 2-3 paragraph analysis. Professional prose, no bullet points. Reference specific numbers from the KPIs provided.",
  "next_priorities": ["string \u2014 actionable next step"]
}

## Rules

1. Notes should be insightful \u2014 identify trends, anomalies, and opportunities. Don't just restate the numbers.
2. Next priorities should be specific and actionable.
3. Reference the computed KPIs and campaign data in your analysis \u2014 they are the source of truth for the numbers.`;

// netlify/functions/report-regenerate-section.ts
var aiSectionOutputSchema = z9.object({
  railshop_notes: z9.string().optional(),
  next_priorities: z9.array(z9.string()).default([])
});
var report_regenerate_section_default = async (request, _context) => {
  if (request.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  const token = getTokenFromHeaders(
    Object.fromEntries(request.headers.entries())
  );
  if (!token) return unauthorized();
  const payload = verifyToken(token);
  if (!payload) return unauthorized("Invalid or expired token");
  if (payload.role !== "admin") return forbidden();
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return jsonResponse({ error: "ANTHROPIC_API_KEY not configured" }, 500);
  }
  const body = await request.json();
  const { reportPeriodId, source, prompt } = body;
  if (!reportPeriodId || !source) {
    return jsonResponse({ error: "reportPeriodId and source required" }, 400);
  }
  const periods = await sql`
    SELECT rp.id, rp.client_id, rp.period_start, c.name as client_name
    FROM report_periods rp
    JOIN clients c ON rp.client_id = c.id
    WHERE rp.id = ${reportPeriodId}
  `;
  if (periods.length === 0) {
    return jsonResponse({ error: "Report period not found" }, 404);
  }
  const { client_id, period_start, client_name } = periods[0];
  const ingestions = await sql`
    SELECT raw_data FROM raw_ingestions
    WHERE client_id = ${client_id} AND source = ${source} AND period_start = ${period_start}
  `;
  if (ingestions.length === 0) {
    return jsonResponse({ error: `No raw data found for ${source}` }, 400);
  }
  const prevDate = /* @__PURE__ */ new Date(period_start + "T00:00:00");
  const prevYear = prevDate.getFullYear() - 1;
  const prevMonth = prevDate.getMonth();
  const prevPeriodStart = `${prevYear}-${String(prevMonth + 1).padStart(2, "0")}-01`;
  const prevIngestions = await sql`
    SELECT raw_data FROM raw_ingestions
    WHERE client_id = ${client_id} AND source = ${source} AND period_start = ${prevPeriodStart}
  `;
  const existingSection = await sql`
    SELECT rs.kpis, cm.campaigns
    FROM report_sections rs
    LEFT JOIN LATERAL (
      SELECT jsonb_agg(jsonb_build_object('campaign_name', cm.campaign_name, 'campaign_type', cm.campaign_type, 'metrics', cm.metrics)) as campaigns
      FROM campaign_metrics cm WHERE cm.report_section_id = rs.id
    ) cm ON true
    WHERE rs.report_period_id = ${reportPeriodId} AND rs.source = ${source}
  `;
  const mechanicalKpis = existingSection[0]?.kpis;
  const mechanicalCampaigns = existingSection[0]?.campaigns;
  const sourceLabel = SOURCE_LABELS[source] || source;
  const dataContext = buildSectionDataContext(
    source,
    ingestions[0].raw_data,
    prevIngestions[0]?.raw_data,
    mechanicalKpis,
    mechanicalCampaigns
  );
  let userMessage = `Generate the narrative analysis for the ${sourceLabel} section of ${client_name}'s monthly report.
Period: ${period_start}

${dataContext}`;
  if (prompt) {
    userMessage += `

Admin guidance: ${prompt}`;
  }
  try {
    const client = new Anthropic({ apiKey });
    const response = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 2048,
      system: AI_SECTION_SYSTEM_PROMPT,
      messages: [{ role: "user", content: userMessage }]
    });
    const textBlock = response.content.find((b) => b.type === "text");
    const rawOutput = textBlock?.text || "";
    let parsed;
    try {
      let jsonStr = rawOutput.trim();
      jsonStr = jsonStr.replace(/^```(?:json)?\s*\n?/, "");
      jsonStr = jsonStr.replace(/\n?```\s*$/, "");
      jsonStr = jsonStr.trim();
      parsed = JSON.parse(jsonStr);
    } catch {
      return jsonResponse({ error: "Claude returned invalid JSON", rawOutput }, 422);
    }
    const validation = aiSectionOutputSchema.safeParse(parsed);
    if (!validation.success) {
      return jsonResponse({
        error: "Claude output failed schema validation",
        validationErrors: validation.error.issues,
        rawOutput
      }, 422);
    }
    const narrative = validation.data;
    await sql`
      UPDATE report_sections SET
        railshop_notes = ${narrative.railshop_notes || null},
        next_priorities = ${narrative.next_priorities.length > 0 ? narrative.next_priorities : null},
        updated_at = now()
      WHERE report_period_id = ${reportPeriodId} AND source = ${source}
    `;
    return jsonResponse({ status: "success", source });
  } catch (err) {
    return jsonResponse({ error: err.message || "AI generation failed" }, 500);
  }
};
export {
  report_regenerate_section_default as default
};
