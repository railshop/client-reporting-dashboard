
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/db.ts
import { neon } from "@neondatabase/serverless";
var sql = neon(process.env.DATABASE_URL);

// netlify/functions/_shared/auth-middleware.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function getTokenFromHeaders(headers) {
  const auth = headers["authorization"] || headers["Authorization"];
  if (!auth?.startsWith("Bearer ")) return null;
  return auth.slice(7);
}
function unauthorized(message = "Unauthorized") {
  return new Response(JSON.stringify({ error: message }), {
    status: 401,
    headers: { "Content-Type": "application/json" }
  });
}
function forbidden(message = "Forbidden") {
  return new Response(JSON.stringify({ error: message }), {
    status: 403,
    headers: { "Content-Type": "application/json" }
  });
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// src/shared/schemas/sources/ga4.ts
import { z as z2 } from "zod";

// src/shared/schemas/common.ts
import { z } from "zod";
var kpiItemSchema = z.object({
  label: z.string(),
  value: z.string(),
  delta: z.string(),
  direction: z.enum(["up", "down", "neutral"]),
  color: z.enum(["blue", "green", "gold", "default"]).default("default")
});
var columnDefSchema = z.object({
  key: z.string(),
  label: z.string(),
  align: z.enum(["left", "right"]).default("left")
});
var tableDefSchema = z.object({
  title: z.string(),
  columns: z.array(columnDefSchema),
  rows: z.array(z.record(z.string(), z.union([z.string(), z.number()]))),
  footerRow: z.record(z.string(), z.union([z.string(), z.number()])).optional()
});
var overviewSchema = z.object({
  headline: z.string().optional(),
  summary: z.string().optional(),
  hero_stats: z.array(kpiItemSchema).optional(),
  platform_cards: z.array(z.object({
    platform: z.string(),
    metrics: z.array(z.object({
      label: z.string(),
      value: z.string()
    })),
    spend: z.string()
  })).optional()
});

// src/shared/schemas/sources/ga4.ts
var ga4SectionSchema = z2.object({
  kpis: z2.array(kpiItemSchema).min(1),
  tables: z2.object({
    channelBreakdown: tableDefSchema,
    topLandingPages: tableDefSchema
  })
});

// src/shared/schemas/sources/gsc.ts
import { z as z3 } from "zod";
var gscSectionSchema = z3.object({
  kpis: z3.array(kpiItemSchema).min(1),
  tables: z3.object({
    topQueries: tableDefSchema,
    topPages: tableDefSchema,
    positionDistribution: tableDefSchema.optional(),
    deviceBreakdown: tableDefSchema.optional()
  })
});

// src/shared/schemas/sources/google-ads.ts
import { z as z4 } from "zod";
var googleAdsSectionSchema = z4.object({
  kpis: z4.array(kpiItemSchema).min(1),
  tables: z4.object({
    assetGroupPerformance: tableDefSchema.optional()
  })
});
var googleAdsCampaignSchema = z4.object({
  campaign_name: z4.string(),
  campaign_type: z4.string(),
  metrics: z4.object({
    impressions: z4.number(),
    clicks: z4.number(),
    ctr: z4.string(),
    cpc: z4.string(),
    conversions: z4.number(),
    cost_per_conversion: z4.string(),
    spend: z4.string(),
    roas: z4.string().optional()
  })
});

// src/shared/schemas/sources/meta.ts
import { z as z5 } from "zod";
var metaSectionSchema = z5.object({
  kpis: z5.array(kpiItemSchema).min(1),
  tables: z5.object({
    creativeBreakdown: tableDefSchema.optional()
  })
});
var metaCampaignSchema = z5.object({
  campaign_name: z5.string(),
  campaign_type: z5.string(),
  metrics: z5.object({
    reach: z5.number(),
    frequency: z5.string(),
    impressions: z5.number(),
    clicks: z5.number(),
    ctr: z5.string(),
    leads: z5.number(),
    cpl: z5.string(),
    spend: z5.string()
  })
});

// src/shared/schemas/sources/lsa.ts
import { z as z6 } from "zod";
var lsaSectionSchema = z6.object({
  kpis: z6.array(kpiItemSchema).min(1),
  tables: z6.object({}).optional()
});

// src/shared/schemas/sources/servicetitan.ts
import { z as z7 } from "zod";
var servicetitanSectionSchema = z7.object({
  kpis: z7.array(kpiItemSchema).min(1),
  tables: z7.object({
    campaignPerformance: tableDefSchema.optional()
  })
});

// src/shared/schemas/sources/gbp.ts
import { z as z8 } from "zod";
var gbpSectionSchema = z8.object({
  kpis: z8.array(kpiItemSchema).min(1),
  tables: z8.object({
    searchQueries: tableDefSchema.optional(),
    photoViews: tableDefSchema.optional()
  })
});

// src/shared/schemas/sources/index.ts
var sectionSchemaMap = {
  ga4: ga4SectionSchema,
  gsc: gscSectionSchema,
  google_ads: googleAdsSectionSchema,
  meta: metaSectionSchema,
  lsa: lsaSectionSchema,
  servicetitan: servicetitanSectionSchema,
  gbp: gbpSectionSchema
};

// netlify/functions/report-section-upsert.ts
var report_section_upsert_default = async (request, _context) => {
  if (request.method !== "PUT") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  const token = getTokenFromHeaders(
    Object.fromEntries(request.headers.entries())
  );
  if (!token) return unauthorized();
  const payload = verifyToken(token);
  if (!payload) return unauthorized("Invalid or expired token");
  if (payload.role !== "admin") return forbidden();
  const body = await request.json();
  const { reportPeriodId, source, kpis, tables, railshop_notes, next_priorities } = body;
  if (!reportPeriodId || !source) {
    return jsonResponse({ error: "reportPeriodId and source required" }, 400);
  }
  const validSources = Object.keys(sectionSchemaMap);
  if (!validSources.includes(source)) {
    return jsonResponse({ error: `Invalid source: ${source}` }, 400);
  }
  if (kpis !== void 0 && tables !== void 0) {
    const schema = sectionSchemaMap[source];
    const parsed = schema.safeParse({ kpis, tables });
    if (!parsed.success) {
      return jsonResponse(
        { error: "Invalid section data", details: parsed.error.flatten().fieldErrors },
        400
      );
    }
  }
  const result = await sql`
    INSERT INTO report_sections (report_period_id, source, kpis, tables, railshop_notes, next_priorities)
    VALUES (
      ${reportPeriodId},
      ${source},
      ${kpis !== void 0 ? JSON.stringify(kpis) : "[]"}::jsonb,
      ${tables !== void 0 ? JSON.stringify(tables) : "{}"}::jsonb,
      ${railshop_notes ?? null},
      ${next_priorities ?? null}
    )
    ON CONFLICT (report_period_id, source)
    DO UPDATE SET
      kpis = COALESCE(${kpis !== void 0 ? JSON.stringify(kpis) : null}::jsonb, report_sections.kpis),
      tables = COALESCE(${tables !== void 0 ? JSON.stringify(tables) : null}::jsonb, report_sections.tables),
      railshop_notes = COALESCE(${railshop_notes ?? null}, report_sections.railshop_notes),
      next_priorities = COALESCE(${next_priorities ?? null}, report_sections.next_priorities),
      updated_at = now()
    RETURNING id, source, kpis, tables, railshop_notes, next_priorities
  `;
  return jsonResponse({ section: result[0] });
};
export {
  report_section_upsert_default as default
};
