
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/db.ts
import { neon } from "@neondatabase/serverless";
var sql = neon(process.env.DATABASE_URL);

// netlify/functions/_shared/auth-middleware.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function getTokenFromHeaders(headers) {
  const auth = headers["authorization"] || headers["Authorization"];
  if (!auth?.startsWith("Bearer ")) return null;
  return auth.slice(7);
}
function unauthorized(message = "Unauthorized") {
  return new Response(JSON.stringify({ error: message }), {
    status: 401,
    headers: { "Content-Type": "application/json" }
  });
}
function forbidden(message = "Forbidden") {
  return new Response(JSON.stringify({ error: message }), {
    status: 403,
    headers: { "Content-Type": "application/json" }
  });
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// src/shared/schemas/common.ts
import { z } from "zod";
var kpiItemSchema = z.object({
  label: z.string(),
  value: z.string(),
  delta: z.string(),
  direction: z.enum(["up", "down", "neutral"]),
  color: z.enum(["blue", "green", "gold", "default"]).default("default")
});
var columnDefSchema = z.object({
  key: z.string(),
  label: z.string(),
  align: z.enum(["left", "right"]).default("left")
});
var tableDefSchema = z.object({
  title: z.string(),
  columns: z.array(columnDefSchema),
  rows: z.array(z.record(z.string(), z.union([z.string(), z.number()]))),
  footerRow: z.record(z.string(), z.union([z.string(), z.number()])).optional()
});
var overviewSchema = z.object({
  headline: z.string().optional(),
  summary: z.string().optional(),
  hero_stats: z.array(kpiItemSchema).optional(),
  platform_cards: z.array(z.object({
    platform: z.string(),
    metrics: z.array(z.object({
      label: z.string(),
      value: z.string()
    })),
    spend: z.string()
  })).optional()
});

// netlify/functions/report-update.ts
var report_update_default = async (request, _context) => {
  if (request.method !== "PUT") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  const token = getTokenFromHeaders(
    Object.fromEntries(request.headers.entries())
  );
  if (!token) return unauthorized();
  const payload = verifyToken(token);
  if (!payload) return unauthorized("Invalid or expired token");
  if (payload.role !== "admin") return forbidden();
  const body = await request.json();
  const { reportPeriodId, overview, railshop_notes, next_priorities } = body;
  if (!reportPeriodId) {
    return jsonResponse({ error: "reportPeriodId required" }, 400);
  }
  if (overview !== void 0) {
    const parsed = overviewSchema.safeParse(overview);
    if (!parsed.success) {
      return jsonResponse(
        { error: "Invalid overview data", details: parsed.error.flatten().fieldErrors },
        400
      );
    }
  }
  const result = await sql`
    UPDATE report_periods
    SET
      overview = COALESCE(${overview !== void 0 ? JSON.stringify(overview) : null}::jsonb, overview),
      railshop_notes = COALESCE(${railshop_notes ?? null}, railshop_notes),
      next_priorities = COALESCE(${next_priorities ?? null}, next_priorities),
      updated_at = now()
    WHERE id = ${reportPeriodId}
    RETURNING id, period_start, status, overview, railshop_notes, next_priorities, updated_at
  `;
  if (result.length === 0) {
    return jsonResponse({ error: "Report period not found" }, 404);
  }
  return jsonResponse({ period: result[0] });
};
export {
  report_update_default as default
};
