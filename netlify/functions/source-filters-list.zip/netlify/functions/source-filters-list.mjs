
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/db.ts
import { neon } from "@neondatabase/serverless";
var sql = neon(process.env.DATABASE_URL);

// netlify/functions/_shared/auth-middleware.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function getTokenFromHeaders(headers) {
  const auth = headers["authorization"] || headers["Authorization"];
  if (!auth?.startsWith("Bearer ")) return null;
  return auth.slice(7);
}
function unauthorized(message = "Unauthorized") {
  return new Response(JSON.stringify({ error: message }), {
    status: 401,
    headers: { "Content-Type": "application/json" }
  });
}
function forbidden(message = "Forbidden") {
  return new Response(JSON.stringify({ error: message }), {
    status: 403,
    headers: { "Content-Type": "application/json" }
  });
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// netlify/functions/source-filters-list.ts
var source_filters_list_default = async (request, _context) => {
  if (request.method !== "GET") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  const token = getTokenFromHeaders(
    Object.fromEntries(request.headers.entries())
  );
  if (!token) return unauthorized();
  const payload = verifyToken(token);
  if (!payload) return unauthorized("Invalid or expired token");
  if (payload.role !== "admin") return forbidden();
  const url = new URL(request.url);
  const dataSourceId = url.searchParams.get("dataSourceId");
  if (!dataSourceId) {
    return jsonResponse({ error: "dataSourceId is required" }, 400);
  }
  const filters = await sql`
    SELECT id, data_source_id, filter_type, filter_value, label, active
    FROM source_filters
    WHERE data_source_id = ${dataSourceId}
    ORDER BY label ASC NULLS LAST, filter_value ASC
  `;
  return jsonResponse({ filters });
};
export {
  source_filters_list_default as default
};
