
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/db.ts
import { neon } from "@neondatabase/serverless";
var sql = neon(process.env.DATABASE_URL);

// netlify/functions/_shared/auth-middleware.ts
import jwt from "jsonwebtoken";
var JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function getTokenFromHeaders(headers) {
  const auth = headers["authorization"] || headers["Authorization"];
  if (!auth?.startsWith("Bearer ")) return null;
  return auth.slice(7);
}
function unauthorized(message = "Unauthorized") {
  return new Response(JSON.stringify({ error: message }), {
    status: 401,
    headers: { "Content-Type": "application/json" }
  });
}
function forbidden(message = "Forbidden") {
  return new Response(JSON.stringify({ error: message }), {
    status: 403,
    headers: { "Content-Type": "application/json" }
  });
}
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// netlify/functions/source-filters-upsert.ts
var source_filters_upsert_default = async (request, _context) => {
  if (request.method !== "PUT") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  const token = getTokenFromHeaders(
    Object.fromEntries(request.headers.entries())
  );
  if (!token) return unauthorized();
  const payload = verifyToken(token);
  if (!payload) return unauthorized("Invalid or expired token");
  if (payload.role !== "admin") return forbidden();
  const body = await request.json();
  const { dataSourceId, filters } = body;
  if (!dataSourceId || !Array.isArray(filters)) {
    return jsonResponse({ error: "dataSourceId and filters[] are required" }, 400);
  }
  const ds = await sql`SELECT id FROM client_data_sources WHERE id = ${dataSourceId}`;
  if (ds.length === 0) {
    return jsonResponse({ error: "Data source not found" }, 404);
  }
  const results = [];
  for (const f of filters) {
    if (!f.filter_type || !f.filter_value) continue;
    const rows = await sql`
      INSERT INTO source_filters (data_source_id, filter_type, filter_value, label, active)
      VALUES (${dataSourceId}, ${f.filter_type}, ${f.filter_value}, ${f.label || null}, ${f.active ?? true})
      ON CONFLICT (data_source_id, filter_type, filter_value)
      DO UPDATE SET
        label = COALESCE(${f.label || null}, source_filters.label),
        active = ${f.active ?? true}
      RETURNING id, filter_type, filter_value, label, active
    `;
    results.push(rows[0]);
  }
  return jsonResponse({ filters: results });
};
export {
  source_filters_upsert_default as default
};
